#!/usr/bin/env python3
"""Final immutable-snapshot audit. Does not repair or rewrite prior receipts."""
import hashlib,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FROZEN=ROOT/'frozen-b2e7f35'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
provenance=json.loads((FROZEN/'snapshot_provenance.json').read_text())
inventory=json.loads((FROZEN/'inventory.json').read_text())
engine=json.loads((FROZEN/'engine_provenance_verified.json').read_text())
base=json.loads((FROZEN/'baseline-final/summary.json').read_text())
focused=json.loads((FROZEN/'focused-120-final/summary.json').read_text())
failures=[]
blob_check=json.loads((FROZEN/'git_blob_verification.json').read_text())
if not blob_check['passed'] or blob_check['commit']!=provenance['commit'] or blob_check['checked_git_blobs']!=provenance['tracked_file_count']:failures.append('Exact Git blob verification failed')
delta=json.loads((FROZEN/'delta_verification.json').read_text())
if not delta['protected_paths_unchanged']:failures.append('Protected actor/layout paths changed from prior baseline')
baseline_artifact=json.loads((ROOT/'artifact_receipt.json').read_text())
baseline_preserved=sha(Path(baseline_artifact['path']))==baseline_artifact['sha256']
if not baseline_preserved:failures.append('Prior baseline evidence archive changed')
changed=[p for p,h in provenance['tracked_files_sha256'].items() if not (FROZEN/'project'/p).is_file() or sha(FROZEN/'project'/p)!=h]
if changed:failures.append('Archived tracked files changed')
rows=[]
coverage={}
collection_count=0
lifecycle_rows=[]
for group,summary in [('baseline-final',base),('focused-120-final',focused)]:
 if not summary['passed']:failures.append(group+' has failed cases')
 for case in summary['cases']:
  path=FROZEN/group/case['report']; report=json.loads(path.read_text())
  if sha(path)!=case['report_sha256']:failures.append('Report hash mismatch '+str(path))
  if not case['passed'] or case['engine_errors'] or case['source_drift_after_run'] or not report['passed'] or report['source_drift']:failures.append('Failed receipt '+case['name'])
  drift=[p for p,h in report['source_hashes'].items() if not (FROZEN/'project'/p.removeprefix('res://')).is_file() or sha(FROZEN/'project'/p.removeprefix('res://'))!=h]
  if drift:failures.append('Post-suite source mismatch '+case['name'])
  rows.append(dict(group=group,case=case['name'],passed=case['passed'],hz=case['hz'],sight=case.get('sight'),script=case['script'],report=str(path.relative_to(FROZEN)),report_sha256=sha(path),log_sha256=case['log_sha256'],source_count=len(report['source_hashes']),post_suite_source_drift=drift))
  if group=='baseline-final' and case.get('district'):
   coverage[case['district']]=report
  if case.get('collections'):
   collection_count+=case['collections']
   lifecycle_rows.extend(report['receipts'])
expected={row['district']:row['goals'] for row in inventory['inventory']}
if set(coverage)!=set(expected):failures.append('Optional district coverage mismatch')
for district,goals in expected.items():
 report=coverage.get(district,{})
 for goal in goals:
  seen=report.get('goals_observed',{}).get(goal['id'],{})
  if not seen.get('optional') or seen.get('kind')!=goal['kind']:failures.append('Missing optional goal '+district+'/'+goal['id'])
  if goal['reward'] and report.get('actual_rewards',{}).get(district+'/'+goal['id'])!=goal['reward']:failures.append('Missing reward '+district+'/'+goal['id'])
if collection_count!=40:failures.append('Expected 40 real reward collections')
for row in lifecycle_rows:
 reward=next(iter(row['build']['rewards'].values()));build=row['build']
 expected_damage=[v*(1.08 if reward=='force' else 1) for v in [1,1.15,1.8]]
 if not all(math.isclose(a,b,abs_tol=1e-5) for a,b in zip(build['damage'],expected_damage)):failures.append('Wrong force quantity '+row['phase'])
 if not math.isclose(build['capacity'],65 if reward=='vitality' else 60,abs_tol=1e-5):failures.append('Wrong vitality quantity '+row['phase'])
 if not math.isclose(build['run_speed'],224.54 if reward=='agility' else 218,abs_tol=1e-4):failures.append('Wrong agility quantity '+row['phase'])
 if row['health_after']>row['health_before']:failures.append('Pickup healing '+row['phase'])
for name in ['import.log','inventory.log']:
 text=(FROZEN/name).read_text()
 if 'ERROR:' in text or 'SCRIPT ERROR:' in text:failures.append('Engine error in '+name)
unit=(FROZEN/'runner-unit.log').read_text()
if 'Ran 6 tests' not in unit or '\nOK\n' not in unit:failures.append('Runner unit guards failed')
underpass=[]
evac=coverage['city_evac_spine']
for t in evac['trace']:
 x,y=map(float,t['position'].strip('()').split(','))
 if 3800<x<4300 and y>290 and t['grounded'] and not t['closed_shutters']:underpass.append(dict(frame=t['frame'],position=t['position']))
if not underpass:failures.append('No actual rescued-underpass floor trace')
result=dict(passed=not failures,failures=failures,commit=provenance['commit'],production_archive_sha256=provenance['archive_sha256'],tracked_files_unchanged=len(provenance['tracked_files_sha256']),tracked_file_drift=changed,exact_git_blobs_verified=blob_check['checked_git_blobs'],qa_overlay=False,protected_path_changes_since_01105eb=delta['changed_protected_paths'],prior_baseline_archive_preserved=baseline_preserved,prior_baseline_archive_sha256=baseline_artifact['sha256'],production_changes_by_this_worker=[],districts_with_optional_objectives=len(coverage),optional_objectives_covered=sum(len(g) for g in expected.values()),reward_ids_covered=sum(len(r['actual_rewards']) for r in coverage.values()),total_goals_observed=sum(len(r['goals_observed']) for r in coverage.values()),baseline_route_cases=sum(bool(c.get('district')) for c in base['cases']),lifecycle_cases=sum(bool(c.get('collections')) for c in base['cases']),real_reward_collections=collection_count,focused_120hz_route_cases=len(focused['cases']),focused_sight_states=['retained','traded'],runner_guard_tests=6,engine=engine['version'],engine_executable_sha256=engine['executable_sha256'],rescued_underpass_floor_samples=underpass,cases=rows,limitations=['Each route begins with an explicit district fixture; this is not an uninterrupted all-collectibles campaign.','Lifecycle cases additionally use an initial local spawn fixture and real checkpoint controls.','No measured-phase position, velocity, health, enemy, collision or objective writes.','Traded-sight routes use an explicit initial sight fixture, not a preceding Exchange traversal.','The 34 optional campaign objectives are exhaustive; inherited field caches and archives are not exhaustively collected.','No native rendering, audio, controller-hardware, Windows-hardware or human-duration claim.'],human_duration_validated=False,full_campaign_evidence=False)
(FROZEN/'final_summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['cases','rescued_underpass_floor_samples','limitations']},indent=2))
raise SystemExit(0 if result['passed'] else 1)
