import json,os,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
rows=[]
for strategy,play in [('direct',True),('cleanup',True),('settle250',True),('direct',False)]:
 for trial in range(6):
  name=f'{strategy}-play{int(play)}-{trial:02}'
  d=ROOT/'minimal-results'/name;d.mkdir(parents=True,exist_ok=True)
  env=os.environ.copy()
  for k in ('HOME','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME'):
   (d/k).mkdir(exist_ok=True);env[k]=str(d/k)
  cmd=['/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64','--headless','--audio-driver','Dummy','--verbose','--path',str(ROOT/'minimal-engine'),'--script','res://probe.gd','--',f'--strategy={strategy}']
  if not play:cmd.append('--no-play')
  r=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=10)
  s=r.stdout+r.stderr;(d/'engine.log').write_text(s)
  rows.append({'name':name,'strategy':strategy,'play':play,'trial':trial,'exit':r.returncode,'leaked_instances':re.findall(r'^Leaked instance: (.+)$',s,re.M),'diagnostics':[x for x in s.splitlines() if x.startswith(('ERROR:','WARNING:','SCRIPT ERROR:'))],'log':str(d/'engine.log')})
 print(strategy,play,sum(bool(x['leaked_instances']) for x in rows[-6:]),'/6',flush=True)
(ROOT/'minimal-matrix.json').write_text(json.dumps({'scope':'Pure engine project: no game scripts, assets, autoloads or PCK. In-memory silent looping AudioStreamWAV under headless Dummy audio.','trials':rows},indent=2)+'\n')
