#!/bin/sh
set -eu
ROOT=/workspace/scratch/fd16273ade4b/moksha-nov6-exit-audit-b2e7f35
export HOME="$ROOT/native/home" XDG_DATA_HOME="$ROOT/native/data" XDG_CONFIG_HOME="$ROOT/native/config" XDG_CACHE_HOME="$ROOT/native/cache"
if [ -e "$ROOT/native/ordinary-close.log" ]; then echo "Preserving existing receipt" >&2; exit 1; fi
cd "$ROOT/empty-resources"
/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64 --display-driver x11 --audio-driver Dummy --disable-vsync --rendering-method gl_compatibility --verbose --path "$ROOT/empty-resources" --main-pack /workspace/scratch/fd16273ade4b/moksha-nov6-rehearsal-b2e7f35/MOKSHA.pck > "$ROOT/native/ordinary-close.log" 2>&1
printf '%s\n' "$?" > "$ROOT/native/exit-code.txt"
