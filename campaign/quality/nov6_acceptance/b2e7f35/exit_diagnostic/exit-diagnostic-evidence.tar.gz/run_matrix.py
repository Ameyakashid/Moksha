import hashlib, json, os, re, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PCK=Path('/workspace/scratch/fd16273ade4b/moksha-nov6-rehearsal-b2e7f35/MOKSHA.pck')
ENGINE='/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64'
rows=[]
cases=[(scope,strategy,True) for scope in ('bare','director','original','campaign') for strategy in ('direct','cleanup','settle250')]+[('bare','direct',False)]
for scope,strategy,play in cases:
    for trial in range(6):
        name=f'{scope}-{strategy}-play{int(play)}-{trial:02}'
        dest=ROOT/'headless'/name
        dest.mkdir(parents=True,exist_ok=True)
        env=os.environ.copy()
        for k in ('HOME','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME'):
            (dest/k).mkdir(exist_ok=True)
            env[k]=str(dest/k)
        cmd=[ENGINE,'--headless','--audio-driver','Dummy','--verbose','--path',str(ROOT/'empty-resources'),'--main-pack',str(PCK),'--script',str(ROOT/'probe_exit.gd'),'--',f'--scope={scope}',f'--strategy={strategy}']
        if not play: cmd.append('--no-play')
        r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=25)
        content=r.stdout+r.stderr
        (dest/'engine.log').write_text(content)
        marker=[x.split('EXIT_DIAGNOSTIC ',1)[1] for x in content.splitlines() if 'EXIT_DIAGNOSTIC ' in x]
        rows.append({'name':name,'scope':scope,'strategy':strategy,'play':play,'trial':trial,'exit':r.returncode,'marker':json.loads(marker[0]) if len(marker)==1 else None,'leaked_instances':re.findall(r'^Leaked instance: (.+)$',content,re.M),'resources':re.findall(r'^Resource still in use: (.+)$',content,re.M),'diagnostics':[x for x in content.splitlines() if x.startswith(('ERROR:','WARNING:','SCRIPT ERROR:'))],'log':str(dest/'engine.log')})
    group=rows[-6:]
    print(f'{scope} {strategy} play={play}: {sum(bool(x["resources"]) for x in group)}/6 resources, exits={[x["exit"] for x in group]}',flush=True)
report={'pck':str(PCK),'pck_sha256':hashlib.sha256(PCK.read_bytes()).hexdigest(),'probe_sha256':hashlib.sha256((ROOT/'probe_exit.gd').read_bytes()).hexdigest(),'engine':ENGINE,'scope':'Headless Dummy driver; fixture explicitly starts preserved ambience, not soundcard/listening verification. direct=ordinary SceneTree.quit; cleanup=free host +3frames; settle250=free host +3frames +250ms. No production writes.','trials':rows}
(ROOT/'matrix.json').write_text(json.dumps(report,indent=2)+'\n')
