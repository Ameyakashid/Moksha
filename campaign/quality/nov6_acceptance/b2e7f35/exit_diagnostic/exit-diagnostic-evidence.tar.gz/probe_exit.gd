extends SceneTree
# External diagnostic only. No source edits, no checkpoint saves.
var scope := "director"
var strategy := "direct"
var start_audio := true
func _initialize():
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--scope="): scope = arg.trim_prefix("--scope=")
		if arg.begins_with("--strategy="): strategy = arg.trim_prefix("--strategy=")
		if arg == "--no-play": start_audio = false
	call_deferred("run")
func run():
	var host: Node
	var player: AudioStreamPlayer
	if scope == "bare":
		host = Node.new()
		root.add_child(host)
		player = AudioStreamPlayer.new()
		player.stream = load("res://audio/ambience.wav")
		player.stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		player.stream.loop_end = 220500
		host.add_child(player)
	elif scope == "director":
		host = load("res://scripts/systems/audio_director.gd").new()
		root.add_child(host)
		player = host.ambient
	else:
		host = load("res://campaign/campaign.tscn" if scope == "campaign" else "res://demo/mission.tscn").instantiate()
		host.save_enabled = false
		root.add_child(host)
		player = host.audio.ambient
	# Headless normally skips audio. Deliberately start only the original
	# ambience to exercise Godot's Dummy audio retirement without native UI.
	paused = false
	if start_audio: player.play()
	await create_timer(0.12, true).timeout
	paused = true
	var row := {"scope":scope, "strategy":strategy, "audio_started":start_audio, "display":DisplayServer.get_name(), "audio_driver":AudioServer.get_driver_name(), "playing_before_cleanup":player.playing}
	if strategy != "direct":
		if scope == "bare":
			player.stop()
			player.stream = null
		host.free()
		row.host_freed = not is_instance_valid(host)
		row.player_freed = not is_instance_valid(player)
		paused = false
		for i in range(3): await process_frame
		if strategy == "settle250": await create_timer(0.25, true).timeout
	print("EXIT_DIAGNOSTIC ",JSON.stringify(row))
	quit()
