extends SceneTree
func _initialize(): call_deferred("run")
func run():
	var strategy := "direct"
	var play_audio := true
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--strategy="): strategy=arg.trim_prefix("--strategy=")
		if arg == "--no-play": play_audio=false
	var voice := AudioStreamPlayer.new()
	voice.stream = AudioStreamWAV.new()
	voice.stream.format = AudioStreamWAV.FORMAT_16_BITS
	voice.stream.mix_rate = 44100
	voice.stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	voice.stream.loop_end = 220500
	var silence := PackedByteArray()
	silence.resize(441000)
	voice.stream.data = silence
	root.add_child(voice)
	if play_audio: voice.play()
	await create_timer(0.12,true).timeout
	paused = true
	var freed := false
	if strategy != "direct":
		voice.stop()
		voice.stream = null
		voice.free()
		freed = not is_instance_valid(voice)
		paused = false
		for i in range(3): await process_frame
		if strategy == "settle250": await create_timer(0.25,true).timeout
	print("ENGINE_ONLY_DIAGNOSTIC ",JSON.stringify({"strategy":strategy,"play":play_audio,"player_freed":freed}))
	quit()
