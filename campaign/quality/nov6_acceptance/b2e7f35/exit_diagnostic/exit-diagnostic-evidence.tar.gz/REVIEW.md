# MOKSHA ordinary-exit diagnostic, frozen b2e7f35

## Finding and recommendation

**Keep the runtime frozen.** The ordinary Alt-F4 warning is an inherited Godot 4.6.3 / Dummy-audio shutdown-retirement diagnostic, reproducible without MOKSHA scripts or assets. It is not evidence of a new campaign ownership leak. No production changes were made or recommended for this release.

Severity: low, at process exit in the measured environment. All 103 diagnostic executions (one native, 78 PCK-based headless, 24 pure-engine headless) exited with code 0. The retained objects are one looping WAV and its playback, not scene nodes. There was no observed crash or save failure. These tests do not establish hardware soundcard behavior, Windows exit behavior, or a long-session memory profile.

## Exact native evidence

The unchanged actual PCK was launched from an empty resource directory, with no external fixture script, under official Godot 4.6.3, X11, llvmpipe and explicit Dummy audio. Its fresh title screen was visually confirmed, then closed using an actual native Alt-F4. The window disappeared and the terminal returned. Exit code: 0.

PCK SHA-256: `262f3685fa8c1ec4c34c363de77e1b6ed8a3023971a908e66556d01ad2467282`.

`native/ordinary-close.log` reports:

- `AudioStreamPlaybackWAV`, reference count 1.
- `AudioStreamWAV`, reference count 1.
- `Resource still in use: res://audio/ambience.wav (AudioStreamWAV)`.
- The ObjectDB exit warning and one-resource exit error. No Node, campaign script or other resource is listed as leaked.

This is a focused title-close reproduction. The earlier packed manual smoke covered gameplay, focus loss, title/Continue and then ordinary close; its nonverbose log cannot independently name its retained resource. The focused reproduction now establishes the same diagnostic signature on the exact PCK and identifies it precisely.

## Inherited versus new

`scripts/systems/audio_director.gd`, `demo/mission.gd` and `audio/ambience.wav` are byte-for-byte identical between recovered baseline `632b6c9`, frozen runtime `b2e7f35` and the current working files. Hashes are in `provenance.json`.

The existing director already implements `_exit_tree()` at lines 51–56: stop every AudioStreamPlayer/AudioStreamPlayer2D, set its stream to null, and clear the resource cache. Adding another campaign stop/null/cache-clear pass would duplicate existing cleanup and does not address audio-server retirement timing.

## Controlled PCK tests

`probe_exit.gd` is an external test-only SceneTree script. It uses the exact packed assets/scripts, disables checkpoint saving for complete scenes and explicitly starts only the preserved ambience under headless Dummy audio. Normal headless mode would otherwise skip playback and miss this condition.

Six independent processes per cell:

| Scope | Direct quit | Stop/free host, 3 frames | Same cleanup, then 250 ms |
| --- | ---: | ---: | ---: |
| Bare AudioStreamPlayer, no director/campaign | 6/6 warnings | 6/6 | 0/6 |
| Unchanged inherited audio director | 6/6 | 6/6 | 0/6 |
| Unchanged original demo scene | 4/6 | 3/6 | 0/6 |
| Current frozen campaign scene | 5/6 | 3/6 | 0/6 |

A bare-player no-play negative control warned 0/6. Total: 78 processes, all code 0, one valid diagnostic marker each. Every cleanup case confirms the host and player are actually freed. Every resource diagnostic names only `res://audio/ambience.wav`; every leaked object pair is WAV/playback. No unrelated errors occurred. Intermittent rates depend on teardown timing and are not evidence that the campaign introduced or worsened the issue.

## Independent pure-engine reproduction

`minimal-engine/` contains only a minimal project and a fixture that creates an in-memory silent looping AudioStreamWAV and AudioStreamPlayer. It loads no PCK, game assets, game scripts or autoloads.

- Direct quit while paused: 6/6 ObjectDB warnings.
- Explicit stop, stream=null, free, and three frames: 6/6 warnings.
- Same cleanup followed by 250 ms: 0/6 warnings.
- Never play the stream: 0/6 warnings.

All 24 exited code 0. The same WAV/playback pair remains at reference count 1. Because this resource is anonymous rather than a loaded/cached path, the pure-engine reproduction has the ObjectDB warning but no resource-cache-path error. This isolates the problem from MOKSHA ownership and is consistent with asynchronous audio-server retirement at shutdown. It is not an upstream engine-source diagnosis or evidence that every audio driver is affected.

## Smallest safe change and test impact

For this release, the smallest safe change is **documentation and preserving these receipts, with no runtime patch**. Do not filter, suppress or relabel the ordinary-close diagnostics as a clean exit. Existing capture fixtures that wait 250 ms after freeing the host remain legitimate fixture teardown, but are not proof of clean ordinary Alt-F4 behavior.

If warning-free ordinary close becomes a separate requirement, the plausible campaign-only workaround is an idempotent close-request handler that disables automatic immediate quit, stops campaign audio before engine teardown and allows audio-server retirement before quitting. That changes real close behavior and introduces latency; 250 ms is demonstrated only in this environment, not guaranteed for every backend. Another `_exit_tree()` cleanup alone will not help.

Such a future patch needs fresh ordinary native Alt-F4/close-button tests at title, gameplay and all paused/modal states; repeated close requests; confirmation no save mutation or hangs; active one-shots plus ambience; target Windows and real audio-driver checks; and the full campaign regression/package matrices because it changes runtime. Do not add it as speculative late churn.

## Reproduction and evidence

- Native launcher: `Start-native-verbose.sh` (preserves any existing log rather than overwriting it).
- PCK matrix: `run_matrix.py`, `probe_exit.gd`, `matrix.json`, `headless/*/engine.log`.
- Pure-engine matrix: `run_minimal.py`, `minimal-engine/`, `minimal-matrix.json`, `minimal-results/*/engine.log`.
- Exact inherited hashes and native scope: `provenance.json`.
- Compact complete diagnostic bundle: `exit-diagnostic-evidence.tar.gz`.

No production writes, native editor launch, source masking, audio rewrite, or user save changes were performed. The native desktop was returned idle to terminal window 29360131.
