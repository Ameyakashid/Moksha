# Observer corrections, not production defects

- Initial stable-save assertion compared against a checkpoint from before an additional active physics tick. Corrected to save once, then compare repeat saves of unchanged state.
- Initial basic-state seed reset assumed that releasing controller buttons changed the active input device. Releases intentionally do not change that device. The fixture now establishes an actual keyboard key intent.
- Initial controller-held focus retry observer omitted explicit resume after queuing a retry. Production correctly stayed paused. The observer now sends the explicit resume key.
- A finale uniqueness hypothesis was rejected after checking documented deliberate replay semantics and the unchanged original completion append logic. The diagnostic result is preserved separately and is not counted as a production regression.
- Negative-control script replacement orphaned the campaign's pre-ready menu node. Both deliberately broken behaviors were detected, but engine cleanup correctly failed the runner. The final negative fixtures instantiate the broken subclass directly, rather than replacing a script on an already-instantiated campaign. Production is untouched.
