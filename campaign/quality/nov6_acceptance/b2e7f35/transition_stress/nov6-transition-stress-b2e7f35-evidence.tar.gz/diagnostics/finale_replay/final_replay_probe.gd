extends "res://campaign/quality/nov6_full_campaign_route.gd"
## Initial final-district checkpoint fixture derives prior metrics/build from an
## existing accepted report. Both final-district traversals are ordinary input.
var probe_output := ""
var attempts: Array[Dictionary] = []
var replay_checks := 0
func _initialize() -> void:
	scene_path = "res://campaign/campaign.tscn"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--hz="): hz = int(arg.trim_prefix("--hz="))
		if arg.begins_with("--out=" ): probe_output = arg.trim_prefix("--out=")
	Engine.physics_ticks_per_second = hz
	run.call_deferred()
func require(ok: bool, label: String) -> void:
	replay_checks += 1
	if not ok: failures.append(label)
func run_last_district() -> void:
	sector_seen = -1; district_id = "crown_choice_threshold"; goals_seen.clear(); interaction_tick = -999; choice_done = true
	for tick in hz * 240:
		frame += 1
		if host.state == "complete": break
		if host.state == "dead": failures.append("Actual-input final-district death"); break
		if host.state == "final_choice": await key(KEY_J)
		elif host.state == "archive": await key(KEY_E)
		elif host.state == "choice": await key(KEY_K)
		elif host.state == "playing":
			if sector_seen != host.sector: begin_sector()
			host.input_override = decide()
			if frame % hz == 0:
				trace.append(snapshot())
				if trace.size() > 50: trace.pop_front()
		await physics_frame; await process_frame
	require(host.state == "complete", "ordinary final-district route reaches complete")
	attempts.append({"state":host.state,"levels":host.level_receipts.duplicate(true),"metrics":host.metrics.duplicate(true),"upgrades":host.upgrades.duplicate(),"elapsed":host.elapsed,"goals":goals_seen.duplicate(true),"result_file":JSON.parse_string(FileAccess.get_file_as_string("user://moksha_five_levels_results.json"))})
func run() -> void:
	var isolated := OS.get_environment("XDG_DATA_HOME").simplify_path()
	if OS.get_environment("MOKSHA_QUALITY_ISOLATED") != "1" or isolated.is_empty() or not OS.get_user_data_dir().simplify_path().begins_with(isolated + "/"):
		printerr("REFUSED: isolated XDG save directory required"); quit(2); return
	input_dispatch = InputDispatch.new(); input_dispatch.process_mode = Node.PROCESS_MODE_ALWAYS; root.add_child(input_dispatch)
	host = load(scene_path).instantiate(); root.add_child(host); host.start_new(true)
	var fixture_path := "res://campaign/tests/full_route_60_neutral_retained.json"
	var fixture: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(fixture_path))
	require(fixture.get("completed",false) and fixture.get("passed",false), "historical report is a completed accepted route")
	if not failures.is_empty(): quit(3); return
	# Declared initialization only. These are historical prefix receipts, not a
	# claim that this probe replays the preceding 31 districts.
	host.metrics.assign(fixture.district_metrics.slice(0,31))
	host.level_receipts.assign(fixture.levels.slice(0,4))
	host.upgrades.assign(fixture.actual_upgrade_choices)
	host.lens = fixture.lens; host.blind = fixture.actual_blind
	host.kills = fixture.kills; host.deaths = fixture.deaths
	host.elapsed = fixture.active_seconds - fixture.district_metrics[-1].seconds
	for receipt in fixture.levels: host.level_seconds[str(int(receipt.level))] = receipt.active_seconds
	host.level_seconds["5"] = maxf(0, float(host.level_seconds["5"]) - float(fixture.district_metrics[-1].seconds))
	host.load_sector(31)
	var baseline := {"metrics":host.metrics.size(),"levels":host.level_receipts.size(),"upgrades":host.upgrades.duplicate()}
	await run_last_district()
	require(host.metrics.size() == 32 and host.level_receipts.size() == 5, "first complete has 32 districts and five levels")
	if failures.is_empty():
		host.input_override = {}
		await key(KEY_N); require(host.state == "title" and host.continue_available, "ending N offers Continue")
		await key(KEY_C); require(host.state == "playing" and host.sector == 31, "Continue reopens final district")
		await run_last_district()
		require(host.metrics.size() == 32 and host.level_receipts.map(func(row):return int(row.level)) == [1,2,3,4,5], "replaying finale does not duplicate district/level completion receipts")
	var report := {"passed":failures.is_empty(),"checks":replay_checks,"failures":failures,"hz":hz,"initial_fixture_source":fixture_path,"initial_fixture_source_sha256":FileAccess.get_sha256(fixture_path),"baseline":baseline,"attempts":attempts,"trace":trace,"scope":"Declared final-district checkpoint fixture from historical route prefix. After initialization, two full last-district traversals use only ordinary actor inputs plus idle-dispatched production keys, separated by genuine ending N/title Continue. No measured-phase position, health, goal, enemy or gate writes."}
	if not probe_output.is_empty(): FileAccess.open(probe_output,FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("FINAL_REPLAY_RESULT " + JSON.stringify(report))
	host.free(); quit(0 if failures.is_empty() else 1)
