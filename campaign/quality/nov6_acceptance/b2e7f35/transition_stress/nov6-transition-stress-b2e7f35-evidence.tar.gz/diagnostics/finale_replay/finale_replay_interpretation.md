# Finale replay: rejected duplicate-write hypothesis

Source: exact `b2e7f352b96b11e9a5137145416ddeaf4a974e27` snapshot, Godot 4.6.3, 60 Hz.

The probe initializes the final-district checkpoint using the first 31 district receipts, first four level receipts and earned build from the preserved accepted `campaign/tests/full_route_60_neutral_retained.json` report. This is an explicit prefix fixture, not a replay of the preceding 31 districts. Thereafter both complete final-district traversals use ordinary production actor inputs and idle-dispatched keys. No measured-phase position, health, goal, enemy or gate writes occur.

Exact user sequence:

1. Complete the final district and choose the public-record ending.
2. Press N to return to title.
3. Press C to Continue, which deliberately reopens the final district.
4. Traverse the district and complete its real required objectives again.
5. Choose the ending again.

First result: 32 district rows, level receipt IDs `[1,2,3,4,5]`, four upgrades, 1346.51666666575 active seconds.
Second result: 33 district rows, IDs `[1,2,3,4,5,5]`, the same four upgrades, 1371.88333333239 active seconds. The +25.3667 seconds corresponds to the second genuine final-district traversal.

The second row is produced by a second completed replay, not by duplicated delivery of one choice. `README.md:56` and `campaign/docs/LOCAL_PLAYTEST.md:30` in the tested snapshot explicitly document final-district replay after Continue. The preserved 9e22722 campaign final-choice handler contains the same append logic. There is no evidence here of a new runtime defect or a lost checkpoint, and no runtime fix was proposed.

The probe initially asserted unique district/level counts after replay. That hypothesis was rejected after checking the documented semantics and original implementation. Its raw `passed: false` report and exact observer source are retained as a diagnostic, excluded from acceptance totals. The later documentation clarification qualifies five level receipts as the first-completion result and explains additional replay receipts.

Files: `final_replay_60.json`, `final_replay_60.log`, and the as-tested `final_replay_probe.gd`. The earlier fixture parsing error is separately labeled as a pilot error and is not gameplay evidence.
