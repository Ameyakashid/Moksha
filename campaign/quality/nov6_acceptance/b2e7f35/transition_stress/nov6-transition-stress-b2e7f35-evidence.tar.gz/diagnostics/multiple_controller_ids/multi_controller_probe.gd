extends SceneTree
var host: Node
var rows: Array[Dictionary] = []
func _initialize() -> void: run.call_deferred()
func frames(count: int) -> void:
	for i in count: await physics_frame; await process_frame
func button(device: int, code: int, pressed: bool) -> void:
	var e := InputEventJoypadButton.new(); e.device=device; e.button_index=code; e.pressed=pressed
	Input.parse_input_event(e); Input.flush_buffered_events()
func run() -> void:
	host=load("res://campaign/campaign.tscn").instantiate(); host.save_enabled=false; root.add_child(host); host.start_new(true)
	for device in [0,1,3]:
		host.start_new(true); await frames(3)
		button(device,JOY_BUTTON_DPAD_RIGHT,true); await frames(3)
		rows.append({"device":device,"raw_right":Input.get_action_strength("cp_right"),"actor_x":host.player._input.x,"legend":host.gamepad_navigation.input_device,"active":host.gamepad_navigation.active_controller})
		button(device,JOY_BUTTON_DPAD_RIGHT,false); await frames(3)
		Input.joy_connection_changed.emit((device+1)%4,false)
		rows[-1].other_disconnect_state=host.state
		Input.joy_connection_changed.emit(device,false)
		rows[-1].active_disconnect_state=host.state
	print("MULTI_CONTROLLER_PROBE "+JSON.stringify(rows))
	host.free(); quit()
