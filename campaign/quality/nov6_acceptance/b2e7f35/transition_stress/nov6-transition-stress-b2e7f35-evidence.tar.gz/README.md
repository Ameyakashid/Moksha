# Exact b2e7f35 transition stress acceptance

All eight planned runs pass against immutable commit `b2e7f352b96b11e9a5137145416ddeaf4a974e27` with Godot `4.6.3.stable.official.7d41c59c4`. No archived source/asset or fixture drift, script errors, engine errors or leaked-object diagnostics were observed in these accepted runs.

- Main matrix: 444 scenarios, 23,790 event steps and 202,265 assertions at 60 Hz, again at 120 Hz, and an exact 60 Hz replay.
- Cumulative four-upgrade matrix: 36 cases and 5,292 assertions at each rate.
- Two deliberately broken test-only implementations fail their exact intended guards, with clean engine shutdown. The non-isolated-save invocation refuses before writing a checkpoint.
- Positive total, including the explicitly repeated run: 617,379 assertions and 76,554 event steps. These totals include repeated coverage, not unique independent behaviors.
- Six Python runner guard unit tests pass separately.

The command/state digest is identical at both rates and on replay: `efbc9043567d82c8a099eb510f98995ea324945c283cc411f73a06fb68b321b4`.

See `accepted/summary.json`, `accepted/source_manifest.json`, `accepted/fixture_manifest.json`, `accepted/engine.json`, and every raw per-run log. `qa_source/` contains the reusable fixtures and runner in their intended project-relative location. Its README documents exact fixture boundaries and reproduction.

This is headless event/state/persistence evidence, not full-campaign traversal, human timing, real USB/Bluetooth controller testing, native Windows execution, audible/rendered review or power-loss durability. Completed-exit and modal-entry locations are declared fixtures; no production runtime files were edited.

## Separate diagnostics, excluded from acceptance totals

- `diagnostics/finale_replay/`: a rejected uniqueness hypothesis. A deliberately replayed and completed final district adds another final-district/level-five history row and active time. It is not a duplicate write from one completion, and matches documented replay and inherited implementation semantics.
- `diagnostics/multiple_controller_ids/`: synthetic device 0 moves the actor; IDs 1 and 3 select campaign prompts and disconnect handling but do not move it with the preserved default device-0 InputMap. This is a compatibility limitation of b2e7f35, not certified support for nonzero IDs. It has been handed off for a separate campaign-only candidate; b2 remains the validated fallback.
- `diagnostics/observer_corrections.md`: earlier observer assumptions and negative-fixture allocation were corrected. Superseded failing preflights are not relabeled as accepted game tests.
