from pathlib import Path
import hashlib,json,subprocess,tarfile,os
ROOT=Path(__file__).resolve().parent
F=ROOT/'frozen-bf3ebd3'; F.mkdir(exist_ok=False)
repo=Path('/workspace/scratch/fd16273ade4b/moksha-campaign')
commit='bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5'
archive=F/'production.tar'
with archive.open('wb') as out: subprocess.run(['git','-C',str(repo),'archive',commit],stdout=out,check=True)
project=F/'project'; project.mkdir()
with tarfile.open(archive) as t:t.extractall(project)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked={}; blobs={};failures=[]
for entry in subprocess.check_output(['git','-C',str(repo),'ls-tree','-rz','--full-tree',commit]).split(b'\0'):
 if not entry: continue
 meta,name=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();name=name.decode();p=project/name
 assert kind=='blob',(name,kind)
 data=os.readlink(p).encode() if mode=='120000' else p.read_bytes()
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if actual!=oid:failures.append(name)
 blobs[name]=oid;tracked[name]=hashlib.sha256(data).hexdigest()
assert not failures,failures
(F/'snapshot_provenance.json').write_text(json.dumps(dict(commit=commit,archive_sha256=sha(archive),tracked_file_count=len(tracked),tracked_files_sha256=tracked,qa_overlay=False),indent=2)+'\n')
(F/'git_blob_verification_before.json').write_text(json.dumps(dict(passed=True,commit=commit,checked_git_blobs=len(blobs),failures=failures,git_blob_ids=blobs),indent=2)+'\n')
protected=['combat_pc','movement','simulation','player.gd','enemy.gd','prop.gd','demo/mission.gd','demo/components','campaign/layouts']
baseline='b2e7f352b96b11e9a5137145416ddeaf4a974e27'
changed=subprocess.check_output(['git','-C',str(repo),'diff','--name-only',baseline,commit,'--',*protected],text=True).splitlines()
(F/'delta_verification.json').write_text(json.dumps(dict(baseline_commit=baseline,new_commit=commit,protected_paths=protected,changed_protected_paths=changed,protected_paths_unchanged=not changed),indent=2)+'\n')
assert not changed,changed
for leaf in ['home','data','config','cache']:(F/'import-profile'/leaf).mkdir(parents=True)
prior=[]
for receipt in ['artifact_receipt.json','artifact_receipt_b2e7f35.json']:
 r=json.loads((ROOT/receipt).read_text());a=Path(r['path']);actual=sha(a);assert actual==r['sha256']
 prior.append(dict(receipt=receipt,archive=str(a),sha256=actual,bytes=a.stat().st_size))
(F/'previous_evidence_reference.json').write_text(json.dumps(dict(previous_archives=prior,unchanged_verified=True),indent=2)+'\n')
print(json.dumps(dict(project=str(project),commit=commit,tracked_file_count=len(tracked),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),protected_paths_unchanged=True,previous_archives_unchanged=True),indent=2))
