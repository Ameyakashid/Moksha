"""Verify frozen source after completed tests, validate acceptance, then archive/copy evidence only."""
from pathlib import Path
import hashlib,json,subprocess,os,tarfile,io,shutil
R=Path(__file__).resolve().parent;F=R/'frozen-bf3ebd3';P=F/'project'
repo=Path('/workspace/scratch/fd16273ade4b/moksha-campaign')
commit='bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dst=repo/'campaign/quality/nov6_acceptance/bf3ebd3/optional'
assert not dst.exists(), 'Refuse to overwrite evidence destination'
assert not (R/'optional-audit-bf3ebd3.tar.gz').exists(), 'Refuse to overwrite evidence archive'
# Read-only exact commit verification, after both immutable test matrices have completed.
for group,n in [('baseline-final',28),('focused-120-final',12)]:
 data=json.loads((F/group/'summary.json').read_text());assert data['passed'] and len(data['cases'])==n
before=json.loads((F/'snapshot_provenance.json').read_text());oldblobs=json.loads((F/'git_blob_verification_before.json').read_text())
blobs={};failures=[];drift=[]
for entry in subprocess.check_output(['git','-C',str(repo),'ls-tree','-rz','--full-tree',commit]).split(b'\0'):
 if not entry:continue
 meta,name=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();name=name.decode();p=P/name;assert kind=='blob'
 data=os.readlink(p).encode() if mode=='120000' else p.read_bytes()
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if actual!=oid:failures.append(name)
 if hashlib.sha256(data).hexdigest()!=before['tracked_files_sha256'][name]:drift.append(name)
 blobs[name]=oid
assert blobs==oldblobs['git_blob_ids']
(F/'git_blob_verification.json').write_text(json.dumps(dict(passed=not failures and not drift,commit=commit,phase='after_all_test_cases',checked_git_blobs=len(blobs),failures=failures,tracked_file_drift=drift,git_blob_ids=blobs),indent=2)+'\n')
assert not failures and not drift
subprocess.run(['python',str(R/'summarize_frozen_bf3ebd3.py')],check=True)
s=json.loads((F/'final_summary.json').read_text());assert s['passed']
(F/'AUDIT.md').write_text(f'''# Optional reward acceptance: bf3ebd3

**PASS on exact commit `{commit}`.** The project was extracted directly with `git archive`, with no overlays or runtime edits.

- 24/24 baseline district routes passed at 60 Hz, using neutral lens and retained sight. All 34 optional campaign goals, 31 reward IDs and 111 total goals were observed before the district exits.
- 12/12 focused routes passed at 120 Hz: City Records, Stamping Galleries, Waterline Clinic, Evacuation Spine, Listening Floor and Crown Ascent, each with retained/traded sight.
- 40 real reward collections passed at 60/120 Hz. Three crate-plate rewards and Foundry agility recovery were each collected initially, after two ordinary R retries, after title Continue and after a fresh host loaded the saved checkpoint. Repeated recovery did not stack rewards; live pickups did not heal. Exact +8% strike, +3% run and +5 capacity quantities were checked.
- Six runner guards passed, including rejecting engine errors with a zero exit, a nonzero exit, missing/failed reports and source drift.
- Clean import and all 40 engine cases had no engine errors or source drift. Every one of the {s['exact_git_blobs_verified']:,} archived files was reverified against its exact Git blob after all tests and remained byte-identical to the initial snapshot.

## Source and records

`final_summary.json` records case receipts and hashes. `snapshot_provenance.json` records the source archive and every initial file SHA-256. `git_blob_verification.json` records the post-test Git identities. `inventory.json` independently enumerates the production optional goals. `delta_verification.json` confirms the protected actor, movement, simulation, demo-controller and campaign-layout paths are unchanged from b2e7f35. The accepted QA observer and runner are unchanged. Engine provenance is included.

`optional-audit-bf3ebd3.tar.gz` contains per-case reports, receipts, logs, QA sources and an embedded size/SHA-256 manifest. `archive_verification.json` records an independent reread of every archive payload member. `SHA256SUMS` indexes this compact directory. Prior 01105eb and b2e7f35 evidence is preserved unchanged.

## Scope limits

Routes use explicit initial district/lens/sight fixtures. Lifecycle checks additionally use an initial local spawn fixture. Measured traversal uses normal production movement/combat inputs and E/Q/menu events, with live damage, enemies and collisions; no measured position, velocity, health, enemy, objective or gate writes occur. These isolated routes do not prove an uninterrupted all-collectibles campaign, exhaustive inherited caches/archives, a preceding Exchange traversal, physical controller hardware, native rendering/audio, Windows hardware or first-play human duration. Default-controller behavior is not inferred from these input-override route tests.
''')
# Verify accepted optional QA sources have not changed since the prior accepted runtime.
qa_changed=subprocess.check_output(['git','-C',str(repo),'diff','--name-only','b2e7f352b96b11e9a5137145416ddeaf4a974e27',commit,'--','campaign/quality/nov6_optional'],text=True).splitlines()
assert not qa_changed,qa_changed
(F/'accepted_observer_identity.json').write_text(json.dumps(dict(passed=True,baseline_commit='b2e7f352b96b11e9a5137145416ddeaf4a974e27',commit=commit,changed_optional_qa_files=qa_changed,runner_sha256=sha(P/'campaign/quality/nov6_optional/run.py'),entry_observer_sha256=sha(P/'campaign/quality/nov6_optional/all_optional_observer_v7.gd')),indent=2)+'\n')
selected={'report.json','receipt.json','summary.json','run.log','inventory.json','inventory.log','final_summary.json','snapshot_provenance.json','git_blob_verification.json','git_blob_verification_before.json','delta_verification.json','engine_provenance_verified.json','AUDIT.md','runner-unit.log','import.log','previous_evidence_reference.json','accepted_observer_identity.json'}
archive_inputs={}
for p in F.rglob('*'):
 if not p.is_file() or P in p.parents or 'import-profile' in p.parts:continue
 if p.name in selected:archive_inputs['evidence/'+str(p.relative_to(F))]=p
for p in (P/'campaign/quality/nov6_optional').rglob('*'):
 if p.is_file() and p.suffix in {'.gd','.py','.md','.uid'}:archive_inputs['qa/'+str(p.relative_to(P))]=p
for name in ['summarize_frozen_bf3ebd3.py','prepare_bf3ebd3.py','finalize_bf3ebd3.py']:archive_inputs['validation/'+name]=R/name
manifest=dict(file_count=len(archive_inputs),files={name:dict(sha256=sha(p),bytes=p.stat().st_size) for name,p in sorted(archive_inputs.items())},scope='Exact bf3ebd3 optional reward acceptance: 24 baseline routes, 12 focused 120 Hz routes, 40 real collections and six runner guards. Full source project and prior evidence packages are not recursively bundled.')
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();a=R/'optional-audit-bf3ebd3.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for name,p in sorted(archive_inputs.items()):t.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('EVIDENCE_MANIFEST.json');info.size=len(manifest_bytes);t.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(a,'r:gz') as t:
 names=t.getnames();assert len(names)==len(set(names));assert set(names)==set(manifest['files'])|{'EVIDENCE_MANIFEST.json'}
 assert t.extractfile('EVIDENCE_MANIFEST.json').read()==manifest_bytes
 for name,expected in manifest['files'].items():
  data=t.extractfile(name).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'],name
previous=json.loads((F/'previous_evidence_reference.json').read_text())
assert all(sha(Path(item['archive']))==item['sha256'] for item in previous['previous_archives'])
receipt=dict(path=str(a),bytes=a.stat().st_size,sha256=sha(a),verified_members=len(names),all_archived_member_hashes_verified=True,final_summary_sha256=sha(F/'final_summary.json'),prior_archives_preserved=True)
(R/'artifact_receipt_bf3ebd3.json').write_text(json.dumps(receipt,indent=2)+'\n')
verification=dict(passed=True,source_commit=commit,qa_overlay=False,archive_file=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a),archive_members=len(names),manifested_payload_members_verified=len(manifest['files']),manifest_member_parsed=True,exact_manifest_member_set=True,all_payload_bytes_and_sha256_verified=True,exact_git_blobs_verified=s['exact_git_blobs_verified'],tracked_files_unchanged=s['tracked_files_unchanged'],prior_evidence_archives_unchanged=True,scope='All payload sizes and SHA-256 values verified against embedded manifest; one additional archive member is the manifest itself. Whole-archive SHA-256 covers all members.')
(F/'archive_verification.json').write_text(json.dumps(verification,indent=2)+'\n')
copy_names=['AUDIT.md','final_summary.json','snapshot_provenance.json','git_blob_verification.json','inventory.json','engine_provenance_verified.json','delta_verification.json','previous_evidence_reference.json','accepted_observer_identity.json','archive_verification.json']
sources={name:F/name for name in copy_names};sources[a.name]=a;sources['artifact_receipt_bf3ebd3.json']=R/'artifact_receipt_bf3ebd3.json'
initial={name:sha(p) for name,p in sources.items()};dst.mkdir(parents=True)
for name,p in sources.items():shutil.copy2(p,dst/name);assert sha(dst/name)==initial[name]
(dst/'EVIDENCE_MANIFEST.json').write_bytes(manifest_bytes)
copy_receipt=dict(source_commit=commit,source_directory=str(F),source_archive=str(a),destination=str(dst),production_or_runtime_edits=False,staged_or_committed=False,copied_files={name:dict(bytes=(dst/name).stat().st_size,sha256=initial[name]) for name in sorted(sources)},source_evidence_unchanged=all(sha(p)==initial[name] for name,p in sources.items()),prior_archives_unchanged=True)
assert copy_receipt['source_evidence_unchanged']
(dst/'copy_receipt.json').write_text(json.dumps(copy_receipt,indent=2)+'\n')
index=''.join(f'{sha(p)}  {p.name}\n' for p in sorted(dst.iterdir()) if p.is_file());(dst/'SHA256SUMS').write_text(index)
for line in index.splitlines():digest,name=line.split('  ',1);assert sha(dst/name)==digest
print(json.dumps(dict(destination=str(dst),source_commit=commit,files={p.name:p.stat().st_size for p in sorted(dst.iterdir())},file_count=len(list(dst.iterdir())),total_bytes=sum(p.stat().st_size for p in dst.iterdir()),archive_sha256=sha(a),sha256_index=sha(dst/'SHA256SUMS'),archive_members_verified=len(names),prior_evidence_unchanged=True),indent=2))
