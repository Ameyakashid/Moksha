extends SceneTree
## Read-only identity/resource audit. Never instantiates or mutates gameplay.
const EXPECTED_PROVENANCE_SHA = "f2c309ea3e1957214788a979f1a45cfcb77b3332578039b5835d237242be859d"
const SOURCE_COMMIT = "c489885befb2264bf2dc0afd2cac8e147d1c9730"
const RUNTIME_COMMIT = "bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5"
var failures:Array[String]=[]
var checks:=0
var observed_sources:Dictionary={}
func check(ok:bool,label:String)->void:
    checks+=1
    if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func collect_route_sources(path:String)->void:
    for file in DirAccess.get_files_at(path):
        if file.ends_with(".gd") or file.ends_with(".tscn") or file.ends_with(".tres"):
            observed_sources[path+"/"+file]=FileAccess.get_sha256(path+"/"+file)
    for folder in DirAccess.get_directories_at(path):collect_route_sources(path+"/"+folder)
func run()->void:
    check(FileAccess.get_sha256("res://BUILD_PROVENANCE.json")==EXPECTED_PROVENANCE_SHA,"packed provenance bytes")
    var provenance=JSON.parse_string(FileAccess.get_file_as_string("res://BUILD_PROVENANCE.json"))
    if not provenance is Dictionary:
        push_error("PACKED_ROUTE_IDENTITY missing provenance");quit(1);return
    check(provenance.source_commit==SOURCE_COMMIT,"frozen source commit")
    check(provenance.runtime_commit==RUNTIME_COMMIT and provenance.runtime_matches_freeze==true,"frozen runtime identity")
    var script_hashes:Dictionary={}
    var resources:Array[String]=[]
    for path in provenance.production_sha256:
        var uri="res://"+str(path)
        if str(path).ends_with(".gd"):
            var digest=FileAccess.get_sha256(uri)
            check(digest==provenance.production_sha256[path],"script hash "+str(path))
            script_hashes[uri]=digest
        if str(path).ends_with(".tscn") or str(path).ends_with(".tres") or str(path).ends_with(".gdshader"):
            check(ResourceLoader.exists(uri) and ResourceLoader.load(uri)!=null,"resource loads "+str(path))
            resources.append(uri)
    for path in ["campaign/quality/nov6_full_campaign_route.gd","campaign/quality/nov6_modal_route_input.gd","campaign/quality/nov6_freight_route_input.gd","campaign/tests/full_campaign_route.gd","campaign/route_tests/l23_route.gd","demo/tests/expanded_mission_route_bot.gd"]:
        check(not FileAccess.file_exists("res://"+path),"QA excluded from resource tree "+path)
    var sectors=load("res://campaign/logic/campaign_data.gd").sectors()
    check(sectors.size()==32,"32 packed authored districts")
    var districts:Array[Dictionary]=[]
    for i in sectors.size():
        var data=sectors[i]
        var goals:Array[Dictionary]=[]
        for goal in data.get("objectives",[]):
            if not goal.get("optional",false):goals.append({"id":str(goal.id),"kind":str(goal.kind)})
        districts.append({"sector":i,"id":str(data.id),"level":int(data.level),"required_goals":goals,"freight_required":data.has("freight"),"required_relays":data.get("relays",[data.relay] if data.has("relay") else []).size()})
    for directory in ["res://campaign","res://demo","res://simulation","res://combat_pc"]:collect_route_sources(directory)
    observed_sources["res://combat_pc/player.gd"]=FileAccess.get_sha256("res://combat_pc/player.gd")
    check(not observed_sources.is_empty(),"route source audit is nonempty")
    for path in observed_sources:check(not str(observed_sources[path]).is_empty(),"route source hash exists "+path)
    var receipt={"passed":failures.is_empty(),"checks":checks,"failures":failures,"source_commit":SOURCE_COMMIT,"runtime_commit":RUNTIME_COMMIT,"provenance_sha256":FileAccess.get_sha256("res://BUILD_PROVENANCE.json"),"production_source_count":provenance.production_sha256.size(),"script_hashes":script_hashes,"resources_loaded":resources,"districts":districts,"route_observed_source_hashes":observed_sources,"scope":"Read-only packed-resource identity check. No gameplay actor instantiated."}
    var output=OS.get_environment("MOKSHA_PACK_AUDIT_REPORT")
    if not output.is_empty():FileAccess.open(output,FileAccess.WRITE).store_string(JSON.stringify(receipt,"  "))
    print("PACKED_ROUTE_IDENTITY ",JSON.stringify(receipt))
    quit(0 if failures.is_empty() else 1)
