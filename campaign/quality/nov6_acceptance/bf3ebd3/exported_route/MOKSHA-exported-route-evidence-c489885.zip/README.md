# Exported MOKSHA continuous campaign check

## Status

**PASS.** The one 60 Hz, neutral, sight-traded continuous route completed all 32 districts with zero deaths, errors or drift. See `REPORT.md` and `evidence/run/summary.json` for the full result and limitations.

## Frozen inputs

- Runtime commit: `bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5`.
- Packaged source/tools commit: `c489885befb2264bf2dc0afd2cac8e147d1c9730`.
- PCK SHA-256: `490c51da2cb17b2d026d55af6e1739914837ae5e2fcefa0aac9fc861c08b04fa`.
- Official Godot: `4.6.3.stable.official.7d41c59c4`.
- Packed provenance SHA-256: `f2c309ea3e1957214788a979f1a45cfcb77b3332578039b5835d237242be859d`.

The PCK itself is not duplicated in this folder. Use the exact existing release PCK. No production resources are copied into the harness.

## Portable reproduction

Copy this folder, the exact PCK, and an official Godot 4.6.3 executable to a machine. With Python 3 installed, run:

```sh
python3 run.py --godot /path/to/godot \
  --pack /path/to/MOKSHA.pck \
  --output /path/to/a-new-evidence-directory
```

The output directory must not already exist. `--repo /path/to/moksha-campaign` is optional: it additionally compares the current main-tree runtime files with the frozen manifest but is never supplied to Godot. Reproduction does not otherwise require the repository or exported staging directory.

The runner:

1. Verifies the exact PCK, QA, and provenance hashes; isolates HOME and XDG paths.
2. Audits packed provenance, 275 script hashes, 228 scene/resource/shader loads, absence of QA in `res://`, and the 32 authored districts. It records the exact packed district/objective/freight/relay requirements.
3. Compiles the external inheritance chain without executing gameplay.
4. Runs exactly one continuous campaign with `--fixed-fps 60 --hz=60 --lens=neutral --district-timeout=480 --sacrifice`.
5. Checks the untouched route receipt plus every ordered district, required goal, relay, freight delivery, level receipt, four upgrade choices, sight decision, public-record finale, zero deaths/errors, hashes, and absence of loose resources.

The wall-clock ceiling is 2,700 seconds, stricter than the historical source runner's 5,400 seconds. The frozen in-game district timeout remains 480 seconds. No production logic or route assertion is relaxed.

## QA path adaptation

Only six necessary frozen QA scripts are copied under `external-qa/`. Their unmodified originals are under `frozen-originals/`. All six originals are identical at both frozen commits. `harness_manifest.json` records before/after SHA-256 values. `qa-path-adaptation.diff` contains the entire six-line adaptation:

- Three QA dependency references in the accepted Nov 6 wrapper become relative external paths.
- The full campaign's QA parent reference becomes a relative external path.
- Its JSON output destination becomes `MOKSHA_ROUTE_REPORT`.
- The L2/L3 navigation QA parent reference becomes a relative external path.

Every production preload/load remains `res://...`, resolved from the PCK. All full-route loops, assertions, ordinary key dispatch, input planning, full actor physics, and the accepted modal-neutral-release/freight-recovery observers remain unchanged.

The inherited navigation scripts also contain historical standalone initializers/runs with isolated fixtures. They are **not executed**: the full campaign overrides `_initialize()` and `run()` without calling the parent versions. The measured route enters through title lens selection and ordinary Enter keys, makes the sight choice through J, and uses ordinary inputs for upgrades/finale. The only host setup switch disables saving. No teleport, health/enemy/goal writes, forced completion, disabled physics, or accelerated time scale is added.

`prepare_harness.py` documents preparation from immutable Git objects and verifies all 817 production inputs against both commits. It is not needed for ordinary reproduction.

## Evidence and scope

- `evidence/runner.log`: runner output, exact commands and result.
- `evidence/run/commands.json`: process exit codes, wall times and log hashes.
- `evidence/run/launch_manifest.json`: exact engine/PCK/harness identity and launch settings.
- `evidence/run/packed_identity.json`: packed preflight, district requirements and source hashes.
- `evidence/run/full_campaign_route.log`: untouched engine/route stdout and stderr.
- `evidence/run/full_route_60_neutral_traded.json`: unchanged full-route receipt content, redirected outside `res://`.
- `evidence/run/summary.json`: independent completion/goal/resource/identity validation.
- `evidence/run/empty-resources/`: must remain empty before and after execution.

The exploratory `evidence/preflight.json` and `.log` are an earlier read-only identity check before relay expectations were added to the external audit. They are preserved, not used as the final route receipt. The final preflight is `evidence/run/packed_identity.json`.

This is an automated, layout-aware Linux/headless test of the actual exported PCK. It is not human traversal, a human-duration measurement, Windows execution, physical-controller testing, audio listening, or target-hardware performance validation. Nothing was committed, uploaded, or published.
