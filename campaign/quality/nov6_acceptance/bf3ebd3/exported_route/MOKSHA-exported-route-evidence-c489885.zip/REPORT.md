# Exported continuous campaign: PASS

Completed 2026-11-07T00:25:12.065464+00:00 after one full route, started 2026-11-07T00:14:49.498464+00:00.

- Actual exported PCK: SHA-256 `490c51da2cb17b2d026d55af6e1739914837ae5e2fcefa0aac9fc861c08b04fa`, unchanged before/after.
- Frozen runtime `bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5`; packaged source/tools `c489885befb2264bf2dc0afd2cac8e147d1c9730`.
- Official Godot `4.6.3.stable.official.7d41c59c4`; neutral lens, actual sight trade, 60 Hz.
- **32/32 ordered districts and actual open-gate receipts; 89/89 required goals; 8/8 relays; 3/3 freight deliveries; 5/5 level receipts; 4/4 ordinary upgrade choices.**
- Upgrades: force, agility, vitality, force. Ending: public record. Sight trade persisted.
- **Zero deaths, route failures, engine errors, packed/runtime/QA drift, or loose resources.**
- 817 production inputs matched both frozen Git commits; 275 packed script hashes and 228 packed scene/resource/shader loads passed. The route's 238 packed source hashes matched the independent preflight.
- Wall time: 622.567 seconds. Simulated active time: 1209.45 seconds. These are not human playtime or target-performance measurements.
- Full physics recorded 46 damage receipts and 130 defeated enemies. Eight accepted modal-neutral-release observations occurred. The accepted freight observer was present, but no follow-up strike was needed in this run.

## Reproduce

Run `python3 run.py --godot /path/to/godot --pack /path/to/MOKSHA.pck --output /path/to/new-evidence` from this harness folder. The source repository is not needed. See `README.md` for exact constraints and optional main-tree verification.

Only six necessary QA scripts are external. The complete six-line path-only adaptation is `qa-path-adaptation.diff`; exact original/adapted hashes are in `harness_manifest.json`. Every production reference remains `res://` and resolves from the PCK. The resource working directory was empty throughout. HOME and all XDG directories were isolated.

No gameplay mutation or shortcut was introduced. The frozen district limit remained 480 seconds, full actor physics remained enabled, and no route assertion changed. Historical fixture runs in the inherited scripts are overridden and never called. No main-source file was edited by this task; unrelated concurrent documentation/test work was left untouched. Nothing was committed, uploaded, or published.

## Raw evidence

- `evidence/run/summary.json`: independent checks for each of all 32 districts.
- `evidence/run/full_route_60_neutral_traded.json`: exact route receipt. SHA-256 `5f759d82064ad289ff62092afaf0220032c3f1161e19dc7f278dd53846c366fc`.
- `evidence/run/full_campaign_route.log`: exact stdout/stderr. SHA-256 `7adeec95a100094991109100c0a3a22729829bbbcafa9a6b44d4544c2f33fc93`.
- `evidence/run/packed_identity.json`, `launch_manifest.json`, `commands.json`: packed identity, resources, exact command, engine identity, timestamps, exit codes and empty-directory checks.
- `SHA256SUMS`: reviewable file checksums.

Scope: **one automated Linux/headless integration route against the shipped-format PCK**, using the accepted layout-aware raw-input/key dispatcher. Not native Windows execution, human traversal, physical-controller testing, audible-output review, or target-hardware acceptance.
