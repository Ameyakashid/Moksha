#!/usr/bin/env python3
"""Read immutable Git objects, copy only six QA files, change only paths."""
import argparse, difflib, hashlib, json, pathlib, subprocess
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--provenance',required=True);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent; repo=pathlib.Path(a.repo)
commit='c489885befb2264bf2dc0afd2cac8e147d1c9730'; runtime='bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5'
qa=['campaign/quality/nov6_full_campaign_route.gd','campaign/quality/nov6_modal_route_input.gd','campaign/quality/nov6_freight_route_input.gd','campaign/tests/full_campaign_route.gd','campaign/route_tests/l23_route.gd','demo/tests/expanded_mission_route_bot.gd']
sha=lambda b:hashlib.sha256(b).hexdigest()
def blob(rev,path):return subprocess.check_output(['git','show',f'{rev}:{path}'],cwd=repo)
provenance=pathlib.Path(a.provenance).read_bytes();prov=json.loads(provenance)
assert prov['source_commit']==commit and prov['runtime_commit']==runtime and prov['runtime_matches_freeze'] is True
for path,digest in prov['production_sha256'].items():
 b=blob(commit,path); assert sha(b)==digest,path; assert blob(runtime,path)==b,path
(root/'expected_provenance.json').write_bytes(provenance)
changes={
 qa[0]: [('"res://campaign/tests/full_campaign_route.gd"','"../tests/full_campaign_route.gd"'),('"res://campaign/quality/nov6_freight_route_input.gd"','"nov6_freight_route_input.gd"'),('"res://campaign/quality/nov6_modal_route_input.gd"','"nov6_modal_route_input.gd"')],
 qa[3]: [('"res://campaign/route_tests/l23_route.gd"','"../route_tests/l23_route.gd"'),('var output:="res://campaign/tests/full_route_%d_%s_%s.json"%[hz,requested_lens,"traded" if sacrifice else "retained"]','var output:=OS.get_environment("MOKSHA_ROUTE_REPORT")')],
 qa[4]: [('"res://demo/tests/expanded_mission_route_bot.gd"','"../../demo/tests/expanded_mission_route_bot.gd"')]
}
manifest={};patch=[]
for path in qa:
 original=blob(commit,path);assert blob(runtime,path)==original,path
 before=original.decode();after=before
 for old,new in changes.get(path,[]):
  assert after.count(old)==1,(path,old);after=after.replace(old,new)
 for subdir,data in [('frozen-originals',original),('external-qa',after.encode())]:
  target=root/subdir/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 manifest[path]={'before_sha256':sha(original),'after_sha256':sha(after.encode()),'changes':changes.get(path,[])}
 patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='frozen/'+path,tofile='external/'+path))
(root/'qa-path-adaptation.diff').write_text(''.join(patch))
(root/'harness_manifest.json').write_text(json.dumps({'source_commit':commit,'runtime_commit':runtime,'pck_sha256':'490c51da2cb17b2d026d55af6e1739914837ae5e2fcefa0aac9fc861c08b04fa','engine':'4.6.3.stable.official.7d41c59c4','provenance_sha256':sha(provenance),'production_files_verified_against_both_commits':len(prov['production_sha256']),'qa':manifest,'production_preloads_unchanged':True,'route_assertions_unchanged':True,'district_timeout_seconds':480,'note':'Only QA dependency strings and full-route JSON output path changed. Parent fixture initializers/runs remain inherited but overridden by full_campaign_route; no isolated-sector fixture is executed.'},indent=2)+'\n')
print(json.dumps({'prepared':True,'qa_files':len(qa),'production_files':len(prov['production_sha256']),'provenance_sha256':sha(provenance)}))
