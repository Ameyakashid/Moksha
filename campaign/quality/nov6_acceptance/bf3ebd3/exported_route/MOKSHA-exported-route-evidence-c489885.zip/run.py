#!/usr/bin/env python3
"""One exported continuous route. Requires only this harness, exact PCK, and Godot."""
import argparse, datetime, hashlib, json, os, pathlib, re, shutil, subprocess, time
ROOT=pathlib.Path(__file__).resolve().parent
ERROR=re.compile(r'^\s*(?:SCRIPT ERROR:|ERROR:|FAIL\b)',re.M)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def require(value,message):
 if not value:raise RuntimeError(message)
def main():
 p=argparse.ArgumentParser();p.add_argument('--pack',required=True);p.add_argument('--output',required=True);p.add_argument('--godot',default='godot');p.add_argument('--repo',help='Optional main-tree runtime drift check; never provided to Godot')
 a=p.parse_args();pack=pathlib.Path(a.pack).resolve();out=pathlib.Path(a.output).resolve();engine=pathlib.Path(shutil.which(a.godot) or a.godot).resolve()
 require(not out.exists(),'Output exists: use a new output directory');out.mkdir(parents=True);empty=out/'empty-resources';empty.mkdir()
 manifest=json.loads((ROOT/'harness_manifest.json').read_text());provenance=json.loads((ROOT/'expected_provenance.json').read_text());commands=[]
 def env(name):
  e=dict(os.environ,MOKSHA_QUALITY_ISOLATED='1',MOKSHA_ROUTE_REPORT=str(out/'full_route_60_neutral_traded.json'),MOKSHA_PACK_AUDIT_REPORT=str(out/'packed_identity.json'))
  for key in ['HOME','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME']:
   path=out/'isolated'/name/key;path.mkdir(parents=True,exist_ok=True);e[key]=str(path)
  return e
 def verify_integrity():
  failures=[]
  if sha(pack)!=manifest['pck_sha256']:failures.append('PCK hash changed')
  for name,item in manifest['qa'].items():
   if sha(ROOT/'external-qa'/name)!=item['after_sha256']:failures.append('external QA changed: '+name)
   if sha(ROOT/'frozen-originals'/name)!=item['before_sha256']:failures.append('original QA changed: '+name)
  if sha(ROOT/'expected_provenance.json')!=manifest['provenance_sha256']:failures.append('expected provenance changed')
  if any(empty.iterdir()):failures.append('resource working directory is not empty')
  if a.repo:
   for name,digest in provenance['production_sha256'].items():
    path=pathlib.Path(a.repo)/name
    if not path.is_file() or sha(path)!=digest:failures.append('main runtime source drift: '+name)
  return failures
 require(not verify_integrity(),'Pre-run identity/drift failure: '+str(verify_integrity()))
 version=subprocess.check_output([str(engine),'--version'],env=env('version'),text=True,stderr=subprocess.STDOUT).strip();require(version==manifest['engine'],'Wrong engine: '+version)
 def run(name,cmd,timeout):
  require(not any(empty.iterdir()),'Loose resource found before '+name)
  start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (out/(name+'.log')).open('w') as log:
   try:result=subprocess.run(cmd,cwd=empty,env=env(name),stdout=log,stderr=subprocess.STDOUT,timeout=timeout);code=result.returncode
   except subprocess.TimeoutExpired:code=124
  raw=(out/(name+'.log')).read_text();errors=[line for line in raw.splitlines() if ERROR.match(line)]
  record={'name':name,'command':cmd,'cwd':str(empty),'started_utc':started,'wall_seconds':round(time.monotonic()-start,3),'exit_code':code,'engine_errors':errors,'log_sha256':sha(out/(name+'.log')),'resource_working_directory_empty':not any(empty.iterdir())};commands.append(record);write(out/'commands.json',commands);print(json.dumps(record),flush=True)
  require(code==0 and not errors and not any(empty.iterdir()),name+' failed; see raw log')
  return raw
 base=[str(engine),'--headless','--path',str(empty),'--main-pack',str(pack)]
 run('identity_preflight',base+['--script',str(ROOT/'verify_pack.gd')],120)
 identity=json.loads((out/'packed_identity.json').read_text());require(identity['passed'] and not identity['failures'],'Packed identity failed')
 script=ROOT/'external-qa/campaign/quality/nov6_full_campaign_route.gd'
 run('compile_only',base+['--script',str(script),'--check-only'],120)
 write(out/'launch_manifest.json',{'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'engine':version,'engine_sha256':sha(engine),'pck':str(pack),'pck_sha256':sha(pack),'harness_manifest_sha256':sha(ROOT/'harness_manifest.json'),'verify_pack_sha256':sha(ROOT/'verify_pack.gd'),'runner_sha256':sha(pathlib.Path(__file__)),'route_script':str(script),'district_timeout_seconds':480,'route_assertions_unchanged':True,'full_actor_physics':True,'resource_working_directory_empty':not any(empty.iterdir()),'main_runtime_source_verified':bool(a.repo),'wall_timeout_seconds':2700})
 print('START_FULL_PACKED_ROUTE',flush=True)
 raw=run('full_campaign_route',base+['--fixed-fps','60','--script',str(script),'--','--hz=60','--lens=neutral','--district-timeout=480','--sacrifice'],2700)
 report_path=out/'full_route_60_neutral_traded.json';r=json.loads(report_path.read_text());failures=[]
 def check(ok,label):
  if not ok:failures.append(label)
 check(r.get('passed') is True and r.get('completed') is True,'route result did not pass/complete')
 check(r.get('hz')==60 and r.get('lens')=='neutral','wrong rate/lens')
 check(r.get('requested_sight_trade') is True and r.get('actual_blind') is True,'sight trade did not persist')
 check(r.get('actual_upgrade_choices')==['force','agility','vitality','force'],'four ordered ordinary upgrade choices missing')
 check(r.get('deaths')==0 and r.get('failures')==[] and r.get('source_drift')==[],'deaths, failures, or source drift')
 check(r.get('human_duration_validated') is False,'human-duration limitation was changed')
 check(r.get('ending')=='public_record','requested ordinary finale choice missing')
 check([int(x['sector']) for x in r.get('district_metrics',[])]==list(range(32)),'32 ordered district completions missing')
 check([int(x['level']) for x in r.get('levels',[])]==[1,2,3,4,5],'five ordered level receipts missing')
 check(r.get('source_hashes')==identity['route_observed_source_hashes'],'packed route source hashes differ from preflight')
 districts=identity['districts'];receipts=r.get('objective_receipts',{});check(set(receipts)=={d['id'] for d in districts},'32 actual gate receipts missing or extra')
 district_checks=[]
 for district in districts:
  got=receipts.get(district['id'],{});actual=got.get('required_goals',[]);expected=district['required_goals']
  goals_ok=[{'id':g['id'],'kind':g['kind']} for g in actual]==expected and all(g.get('completed') is True for g in actual)
  freight_ok=not district['freight_required'] or got.get('freight_latched') is True
  relays_ok=sorted(int(x) for x in got.get('relays',[]))==list(range(district['required_relays']))
  check(goals_ok,district['id']+' required goals incomplete or mismatched');check(freight_ok,district['id']+' freight not latched');check(relays_ok,district['id']+' relays incomplete')
  district_checks.append({'sector':district['sector'],'id':district['id'],'required_goals':len(expected),'all_required_goals_complete':goals_ok,'freight_required':district['freight_required'],'freight_complete':freight_ok,'required_relays':district['required_relays'],'all_relays_complete':relays_ok})
 for receipt in r.get('levels',[]):
  ends=[d['id'] for d in districts if d['level']==int(receipt['level'])];check(bool(ends) and receipt['completed_district']==ends[-1],'incorrect level completion district')
 entries=re.findall(r'^CAMPAIGN_ENTER \d+ (\S+) time=',raw,re.M);check(entries==[d['id'] for d in districts],'raw log does not show all 32 districts in order')
 check(raw.count('FULL_CAMPAIGN_RESULT ')==1,'expected exactly one final route marker')
 integrity=verify_integrity();failures.extend(integrity)
 events=r.get('events',[])
 summary={'passed':not failures,'failures':failures,'source_commit':manifest['source_commit'],'runtime_commit':manifest['runtime_commit'],'pck_sha256':sha(pack),'pck_unchanged':sha(pack)==manifest['pck_sha256'],'production_source_files_verified':manifest['production_files_verified_against_both_commits'],'packed_scripts_verified':len(identity['script_hashes']),'packed_resources_loaded':len(identity['resources_loaded']),'route_source_hashes_verified':len(r.get('source_hashes',{})),'districts_completed':len(r.get('district_metrics',[])),'actual_gate_receipts':len(receipts),'district_checks':district_checks,'levels_completed':len(r.get('levels',[])),'upgrade_choices':r.get('actual_upgrade_choices'),'active_seconds':r.get('active_seconds'),'route_wall_seconds':commands[-1]['wall_seconds'],'actual_blind':r.get('actual_blind'),'deaths':r.get('deaths'),'ending':r.get('ending'),'engine_errors':sum((x['engine_errors'] for x in commands),[]),'source_drift':r.get('source_drift'),'integrity_drift':integrity,'observer_modal_release_count':sum(e.get('event')=='observer_modal_controls_released' for e in events),'observer_freight_strike_count':sum(e.get('event')=='observer_short_delivery_followup_strike' for e in events),'raw_route_sha256':sha(report_path),'raw_log_sha256':sha(out/'full_campaign_route.log'),'resource_working_directory_empty':not any(empty.iterdir()),'scope':'One continuous headless exported PCK route using frozen layout-aware ordinary-input QA, full actor physics, and accepted modal/freight observers. No loose production resources, gameplay state/position/health edits, forced objectives, time-limit increases, human traversal, Windows hardware, physical controller, or target-performance claim.'}
 write(out/'summary.json',summary);print('PACKED_FULL_CAMPAIGN_RESULT '+json.dumps(summary),flush=True);return 0 if not failures else 1
if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as error:
  print('HARNESS_FAILURE '+str(error),flush=True);raise
