#!/usr/bin/env python3
"""Bounded parser/setup negatives. Never launch Godot or alter original evidence."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import run_portable as wrapper

ROOT = Path(__file__).resolve().parent

class PortableTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.historical = (ROOT/'historical/raw/pair1-baseline.log').read_text()
        cls.result, cls.count = wrapper.parse_receipt(cls.historical,'baseline','pair1-baseline')

    def emit(self,result):
        return wrapper.MARKER+json.dumps(result)+'\n'

    def reject(self,text,label='baseline',run='pair1-baseline',mode='timing'):
        with self.assertRaises(wrapper.ValidationError):
            wrapper.parse_receipt(text,label,run,mode)

    def test_historical_timing_and_retention_receipts(self):
        files = list((ROOT/'historical/raw').glob('pair*-*.log')) + list((ROOT/'historical/raw').glob('retention[12]-*.log'))
        self.assertEqual(len(files),16)
        for path in files:
            with self.subTest(path=path.name):
                label=path.stem.split('-')[-1]
                result,count=wrapper.parse_receipt(path.read_text(),label,path.stem,'retention' if path.stem.startswith('retention') else 'timing')
                self.assertIs(type(count),int)
                self.assertGreater(count,0)

    def test_missing_marker(self):
        self.reject('Godot completed with exit zero\n')

    def test_duplicate_marker(self):
        self.reject(self.historical+'\n'+self.emit(self.result))

    def test_malformed_json(self):
        self.reject(wrapper.MARKER+'{bad json}\n')

    def test_duplicate_json_key(self):
        self.reject(wrapper.MARKER+'{"passed":true,"passed":false}\n')

    def test_nonfinite_json(self):
        self.reject(wrapper.MARKER+'{"passed":NaN}\n')

    def test_boolean_success_not_truthiness(self):
        for value in [False,1,'true',None]:
            with self.subTest(value=value):
                result=copy.deepcopy(self.result);result['passed']=value;self.reject(self.emit(result))

    def test_invalid_checks(self):
        for value in [[],0,True,1,None,[{'ok':False,'name':'failure'}],[{'ok':True}]]:
            with self.subTest(value=value):
                result=copy.deepcopy(self.result);result['checks']=value;self.reject(self.emit(result))

    def test_invalid_integer_check_count(self):
        for value in [0,-1,True,1.5,'31',self.count+1]:
            with self.subTest(value=value):
                result=copy.deepcopy(self.result);result['check_count']=value;self.reject(self.emit(result))

    def test_failures_and_diagnostics(self):
        for key in ['failures','diagnostics']:
            with self.subTest(key=key):
                result=copy.deepcopy(self.result);result[key]=['problem'];self.reject(self.emit(result))
        self.reject('ERROR: native failure\n'+self.historical)
        self.reject('SCRIPT ERROR: parsing failed\n'+self.historical)
        self.reject('WARNING: issue\n'+self.historical)

    def test_wrong_run(self):
        self.reject(self.historical,run='pair2-baseline')

    def test_nonpositive_iterations(self):
        result=copy.deepcopy(self.result);result['results'][0]['measurements'][0]['iterations']=0;self.reject(self.emit(result))

    def test_missing_scenario(self):
        result=copy.deepcopy(self.result);result['results'].pop();self.reject(self.emit(result))

    def test_existing_output_refusal_preserves_sentinel(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);repository=root/'repo';repository.mkdir();output=root/'existing';output.mkdir()
            sentinel=output/'sentinel';sentinel.write_text('preserve me')
            process=subprocess.run([sys.executable,str(ROOT/'run_portable.py'),'--repository',str(repository),'--output',str(output)],capture_output=True,text=True)
            self.assertNotEqual(process.returncode,0)
            self.assertIn('refusing to overwrite',process.stderr)
            self.assertEqual(sentinel.read_text(),'preserve me')
            self.assertEqual(sorted(p.name for p in output.iterdir()),['sentinel'])

    def test_existing_file_and_symlink_refusal(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);path=root/'file';path.write_text('stay')
            for existing in [path,root/'link']:
                if existing.name=='link':existing.symlink_to(root/'absent')
                with self.subTest(existing=existing.name),self.assertRaises(wrapper.ValidationError):
                    wrapper.claim_output(existing)
            self.assertEqual(path.read_text(),'stay')

    def test_source_hash_change_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'baseline').mkdir();path=root/'baseline/source.gd';path.write_text('original')
            manifest={'baseline':{'files':{'source.gd':wrapper.digest(path)}}}
            self.assertEqual(wrapper.verify_sources(root,manifest),{'baseline':[]})
            path.write_text('changed')
            with self.assertRaises(wrapper.ValidationError):wrapper.verify_sources(root,manifest)

if __name__=='__main__':
    unittest.main(verbosity=2)
