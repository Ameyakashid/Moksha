#!/usr/bin/env python3
"""Safely reproduce frozen MOKSHA sampling measurements in a NEW directory.
Python 3.12+, git, nice, and Godot 4.6.3 required. No production edits.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
COMMITS = {
    "baseline": "b2e7f352b96b11e9a5137145416ddeaf4a974e27",
    "candidate": "bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5",
}
MARKER = "SAMPLING_BENCH_RESULT "
SCENARIOS = ["neutral", "held_device0", "blocked_device0", "initial_held_device0", "explicit_override"]
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
DIAGNOSTIC = re.compile(r"\b(?:SCRIPT ERROR|ERROR|WARNING|FATAL|Traceback|Segmentation fault)\s*:", re.I)

class ValidationError(RuntimeError):
    pass

def require(condition, message):
    if not condition:
        raise ValidationError(message)

def now():
    return datetime.now(timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_json(path, value):
    # Refuse reuse even inside this freshly claimed output directory.
    with Path(path).open("x", encoding="utf-8") as out:
        json.dump(value, out, indent=2, allow_nan=False)
        out.write("\n")

def diagnostics(text):
    return [line for line in text.splitlines() if DIAGNOSTIC.search(ANSI.sub("", line))]

def strict_json(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    def bad_constant(value):
        raise ValidationError("Non-finite JSON value: " + value)
    try:
        return json.loads(text, object_pairs_hook=unique, parse_constant=bad_constant)
    except (ValueError, TypeError) as error:
        raise ValidationError("Malformed JSON receipt: " + str(error)) from error

def positive_int(value):
    return type(value) is int and value > 0

def parse_receipt(text, label, run, mode="timing"):
    """Strictly validate one original engine receipt; return original + integer check count."""
    require(not diagnostics(text), "Engine diagnostics present")
    # Count marker occurrences, including malformed/embedded/duplicate markers.
    require(text.count(MARKER.strip()) == 1, "Expected exactly one result marker")
    lines = [line for line in text.splitlines() if line.startswith(MARKER)]
    require(len(lines) == 1, "Missing well-formed result marker line")
    result = strict_json(lines[0][len(MARKER):])
    require(type(result) is dict, "Receipt must be a JSON object")
    require(result.get("passed") is True, "Receipt did not report passed true")
    require(result.get("label") == label and result.get("run") == run, "Receipt label/run mismatch")
    require(result.get("failures", []) == [], "Receipt contains failures")
    require(result.get("diagnostics", []) == [], "Receipt contains diagnostics")
    # Frozen harnesses have a checks array. Validate each check, then expose the
    # exact positive integer count in wrapper receipts without rewriting history.
    checks = result.get("checks")
    require(type(checks) is list and len(checks) > 0, "Missing or empty checks array")
    require(all(type(c) is dict and c.get("ok") is True and type(c.get("name")) is str and bool(c["name"]) for c in checks), "Malformed or failed check")
    count = len(checks)
    require(positive_int(count), "Check count must be a positive integer")
    if "check_count" in result:
        require(positive_int(result["check_count"]) and result["check_count"] == count, "Invalid integer check_count")
    cases = result.get("results")
    require(type(cases) is list and [x.get("scenario") for x in cases if type(x) is dict] == SCENARIOS, "Missing, duplicate, malformed or out-of-order scenario")
    for case in cases:
        require(type(case.get("raw_snapshot")) is dict, "Missing raw snapshot")
        rows = case.get("measurements")
        require(type(rows) is list, "Missing measurements")
        if mode == "timing":
            require(len(rows) == 8, "Expected eight timed batches per scenario")
            require(sorted((m.get("batch"), m.get("method")) for m in rows) == sorted((b,m) for b in range(4) for m in ["raw","hud"]), "Invalid batch/method coverage")
            for row in rows:
                expected = 4000 if row["method"] == "raw" else 1000
                require(type(row.get("iterations")) is int and row["iterations"] == expected, "Invalid iteration count")
                require(positive_int(row.get("elapsed_usec")), "Nonpositive or noninteger elapsed time")
                value = row.get("usec_per_call")
                require(type(value) in (int,float) and math.isfinite(value) and value > 0, "Invalid per-call time")
                require(math.isclose(value, row["elapsed_usec"] / expected, rel_tol=1e-10, abs_tol=1e-10), "Inconsistent timing arithmetic")
        else:
            require(len(rows) == 1, "Expected one retention record")
            row = rows[0]
            require(type(row.get("raw_calls")) is int and row["raw_calls"] == 24000 and type(row.get("hud_calls")) is int and row["hud_calls"] == 6000, "Invalid retention call count")
            values = row.get("memory_samples")
            require(type(values) is list and len(values) == 7 and all(type(x) is int and x >= 0 for x in values), "Malformed memory checkpoints")
    return result, count

def claim_output(path):
    output = Path(path).expanduser().absolute()
    try:
        output.mkdir()  # atomic refusal of existing directory/file/symlink
    except FileExistsError as error:
        raise ValidationError("Output already exists; refusing to overwrite: " + str(output)) from error
    return output.resolve()

def fresh_env(output, name):
    home = output / "homes" / name
    env = dict(os.environ)
    for key, sub in [("HOME","home"),("XDG_CONFIG_HOME","config"),("XDG_CACHE_HOME","cache"),("XDG_DATA_HOME","data")]:
        path = home / sub
        path.mkdir(parents=True, exist_ok=False)
        env[key] = str(path)
    return env

def run_command(command, output, name, timeout, env):
    record = {"command": command, "utc_start": now(), "load_before": list(os.getloadavg())}
    start = time.perf_counter()
    log = output / "raw" / (name + ".log")
    with log.open("x", encoding="utf-8") as stream:
        process = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
    record.update(exit_code=process.returncode, wall_seconds=time.perf_counter()-start, load_after=list(os.getloadavg()), utc_end=now())
    text = log.read_text(encoding="utf-8")
    record["diagnostic_lines"] = diagnostics(text)
    require(process.returncode == 0, f"{name}: process exit {process.returncode}; inspect {log}")
    require(not record["diagnostic_lines"], f"{name}: engine diagnostics; inspect {log}")
    return record, text

def verify_sources(output, manifest):
    changed = {}
    for label, data in manifest.items():
        changed[label] = [path for path, expected in data["files"].items() if not (output/label/path).is_file() or digest(output/label/path) != expected]
    require(not any(changed.values()), "Archived source hashes changed: " + repr(changed))
    return changed

def archive_sources(repository, output):
    historical = strict_json((ROOT/"historical/source_manifest.json").read_text())
    actual = {}
    for label, commit in COMMITS.items():
        verified = subprocess.check_output(["git","-C",str(repository),"rev-parse",commit+"^{commit}"], text=True).strip()
        require(verified == commit, "Requested commit identity mismatch")
        archive = output/(label+".tar")
        with archive.open("xb") as stream:
            subprocess.run(["git","-C",str(repository),"archive","--format=tar",commit], stdout=stream, check=True)
        target = output/label
        target.mkdir()
        with tarfile.open(archive) as tar:
            members = tar.getmembers()
            for item in members:
                path = PurePosixPath(item.name)
                require(not path.is_absolute() and ".." not in path.parts, "Unsafe archive member")
                require(item.isfile() or item.isdir(), "Unsupported archive link/special member")
            tar.extractall(target, members=members, filter="data")
        files = {str(p.relative_to(target)):digest(p) for p in sorted(target.rglob("*")) if p.is_file()}
        require(historical[label]["commit"] == commit and files == historical[label]["files"], "Archive differs from frozen historical source manifest")
        actual[label] = {"commit":commit, "files":files}
        # Retain exact archive hash, not a duplicate full source archive.
        write_json(output/(label+"_archive.json"), {"commit":commit,"tar_sha256":digest(archive),"files":len(files)})
        archive.unlink()
    write_json(output/"source_manifest.json", actual)
    return actual

def stage_harnesses(output):
    expected = strict_json((ROOT/"frozen_harness_sha256.json").read_text())
    target = output/"harness"
    target.mkdir()
    for relative, sha in expected.items():
        source = ROOT/"historical"/relative
        require(digest(source) == sha, "Frozen harness hash mismatch: " + relative)
        shutil.copy2(source, target/source.name)
    write_json(output/"staged_harness_sha256.json", {str(p.relative_to(output)):digest(p) for p in sorted(target.iterdir())})

def run_measurement(output, godot, nice, label, run, mode):
    script = "sampling_bench.gd" if mode == "timing" else "retention_bench.gd"
    command = [nice,"-n","10",godot,"--headless","--audio-driver","Dummy","--path",str(output/label),"--script",str(output/"harness"/script),"--",f"--label={label}",f"--run={run}"]
    record, text = run_command(command, output, run, 60, fresh_env(output, run))
    result, count = parse_receipt(text, label, run, mode)
    record.update(result=result, checks=count, passed=True, failures=[], provenance="new_wrapper_run_not_historical")
    write_json(output/"raw"/(run+".json"), record)
    print(f"{run}: {count} checks passed", flush=True)
    return record

def run(args):
    require(sys.version_info >= (3,12), "Python 3.12+ required for safe tar extraction")
    repository = Path(args.repository).expanduser().resolve(strict=True)
    requested = Path(args.output).expanduser().absolute()
    require(not requested.resolve().is_relative_to(repository), "Output must be outside the source repository")
    require(not requested.resolve().is_relative_to(ROOT), "Output must be outside this evidence bundle")
    output = claim_output(requested)
    try:
        (output/"raw").mkdir()
        godot = shutil.which(args.godot)
        nice = shutil.which("nice")
        require(godot is not None and nice is not None, "Godot and nice executables are required")
        godot = str(Path(godot).resolve())
        write_json(output/"run_identity.json", {"started_utc":now(),"kind":"setup_smoke_not_performance_acceptance" if args.smoke else "new_independent_benchmark", "repository":str(repository),"commits":COMMITS,"wrapper_sha256":digest(__file__),"godot_binary":godot,"godot_sha256":digest(godot),"historical_samples_reused":False,"smoke":args.smoke})
        version_record, version_text = run_command([godot,"--version"],output,"version",30,fresh_env(output,"version"))
        require("4.6.3.stable.official.7d41c59c4" in version_text.splitlines(), "Frozen benchmark requires Godot 4.6.3.stable.official.7d41c59c4")
        write_json(output/"engine_version.json",version_record)
        stage_harnesses(output)
        sources = archive_sources(repository,output)
        for label in COMMITS:
            record, _ = run_command([nice,"-n","10",godot,"--headless","--audio-driver","Dummy","--path",str(output/label),"--editor","--import"],output,label+"-import",180,fresh_env(output,label+"-import"))
            write_json(output/"raw"/(label+"-import.json"),record)
        verify_sources(output,sources)
        records = []
        if args.smoke:
            for label in COMMITS:
                records.append(run_measurement(output,godot,nice,label,"smoke-"+label,"timing"))
        else:
            for prefix, pairs, mode in [("pair",6,"timing"),("retention",2,"retention")]:
                for pair in range(pairs):
                    order = ["baseline","candidate"] if pair % 2 == 0 else ["candidate","baseline"]
                    for label in order:
                        records.append(run_measurement(output,godot,nice,label,f"{prefix}{pair+1}-{label}",mode))
                        time.sleep(0.5)
        integrity = verify_sources(output,sources)
        if not args.smoke:
            record, _ = run_command([sys.executable,str(output/"harness/analyze.py")],output,"analysis",60,fresh_env(output,"analysis"))
            write_json(output/"analysis_execution.json",record)
        checks = sum(r["checks"] for r in records)
        require(positive_int(checks), "Wrapper must report positive integer checks")
        receipt = {"passed":True,"checks":checks,"failures":[],"diagnostics":[],"finished_utc":now(),"mode":"setup_smoke_not_performance_acceptance" if args.smoke else "new_independent_benchmark","measurement_processes":len(records),"source_file_changes":integrity,"source_hashes_unchanged":True,"historical_samples_reused":False}
        write_json(output/"wrapper_receipt.json",receipt)
        print("PORTABLE_BENCH_WRAPPER_RESULT "+json.dumps(receipt,allow_nan=False))
        return 0
    except Exception as error:
        write_json(output/"FAILED.json",{"passed":False,"error":str(error),"type":type(error).__name__,"utc":now(),"reuse_forbidden":True})
        raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository",required=True,help="Local Git repository containing both frozen commit objects")
    parser.add_argument("--output",required=True,help="NEW, nonexistent directory outside repository and evidence bundle; parent must exist")
    parser.add_argument("--godot",default="godot",help="Godot 4.6.3 binary name/path")
    parser.add_argument("--smoke",action="store_true",help="Setup validation plus one baseline/candidate pair, not replacement benchmark evidence")
    args = parser.parse_args()
    try:
        return run(args)
    except (ValidationError,OSError,subprocess.SubprocessError) as error:
        print("PORTABLE_BENCH_ERROR: "+str(error),file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
