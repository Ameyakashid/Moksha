# MOKSHA controller sampling comparison: portable evidence

## Result and limits

The original six balanced timing pairs found raw-device sampling approximately **9× slower relatively**, from about 4.9 to 43–45 µs/call. The added absolute cost was about 38–39 µs per raw read and 37–41 µs per playing HUD snapshot. Explicit input overrides were effectively unchanged. Separate retention blocks had flat object/resource counts and exactly flat native static-memory checkpoints.

These are headless, frozen-state input/HUD microbenchmarks on a shared cloud CPU, **not FPS, full-renderer/campaign performance, target-machine, Windows, physical-controller, audio, or allocation-event-count measurements**. No optimization or production change is proposed. See `historical/REPORT.md` for method, variability, caveats and the original findings.

## Safe reproduction

Requirements: Python 3.12+, Git, POSIX `nice`, and Godot **4.6.3.stable.official.7d41c59c4**. The wrapper was smoke-tested on Linux; macOS was not tested. Native Windows execution of this POSIX wrapper is not supported. The local repository must contain both commits; no network access, installation or repository changes are performed.

```sh
python3 run_portable.py \
  --repository /absolute/path/to/moksha-campaign \
  --output /absolute/path/to/NEW-sampling-run
```

Use `--godot /absolute/path/to/godot` if needed. The output parent must exist. The output itself **must not exist**, including as an empty directory, file or symlink, and must be outside the repository and this evidence bundle. Existing output is refused, never resumed or overwritten. Failed output also must not be reused; choose a new name.

The wrapper:

1. Claims a new directory atomically; records a distinct run identity and binary/wrapper hashes.
2. Creates its own exact Git archives of baseline `b2e7f352b96b11e9a5137145416ddeaf4a974e27` and candidate `bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5`, safely extracts them, and compares every source file with the frozen original manifest.
3. Stages byte-identical historical harnesses after checking their SHA-256 hashes. It imports each isolated archive with fresh HOME/XDG paths.
4. Runs the unchanged GDScript sampling workloads in the original six AB/BA timing pairs and two AB/BA retention pairs, sequentially at nice +10, with fresh HOME/XDG paths per process.
5. Requires successful exits, exactly one well-formed engine result marker, literal `passed: true`, nonempty all-passing check records, no failures/diagnostics, complete measurement structure, and unchanged source hashes. It rejects duplicate JSON keys, non-finite JSON and invalid timing counts.
6. Runs the historical analysis script against the **new** measurements and writes `wrapper_receipt.json`. Its `checks` field is a positive integer derived from validated engine checks. The original engine receipt's checks array is retained unchanged in each raw record.

For a bounded setup check instead of the complete comparison:

```sh
python3 run_portable.py --repository /absolute/path/to/repo \
  --output /absolute/path/to/NEW-smoke --smoke
```

This runs one baseline/candidate pair and labels it `setup_smoke_not_performance_acceptance`. It does not produce a replacement comparison summary or reuse historical samples. Original six-pair statistics must not be described as results of a wrapper rerun.

## Evidence and validation

- `historical/`: original report, raw logs/JSON, scripts, environment, source manifest and hashes, preserved byte-for-byte. Original scripts have weaker output guards; **use the wrapper**, not those scripts directly. Absolute paths in historical logs are historical provenance, not prerequisites.
- `run_portable.py`: new safe setup/orchestration wrapper. It runs the same frozen GDScript workloads; it does not edit production or change sample counts.
- `test_portable.py`: 16 passing parser/setup tests, including existing directory/file/symlink refusal, missing/duplicate/malformed receipts, failed checks, wrong identities and source-hash changes. Run `PYTHONDONTWRITEBYTECODE=1 python3 test_portable.py`.
- `wrapper_validation/`: a separate fresh two-process smoke passed **67 checks**, no diagnostics, both source manifests unchanged. Existing-output refusal was also exercised against that completed directory. This smoke is setup validation only; there was **no new full benchmark rerun**.
- One initial unit-test run had a test-discovery glob count failure because it included `retention-runner.log`. The glob was corrected, all 16 tests then passed, and the initial log is retained transparently. This was not an engine/benchmark failure and did not affect original measurements.
- `SHA256SUMS`: SHA-256 for every bundled file except this manifest itself. Verify from the bundle root with `sha256sum -c SHA256SUMS` (or equivalent).

Full source snapshots, HOME/XDG state, `.godot`, caches and compiled bytecode are excluded from this compact bundle. They will exist only in a newly requested reproduction output. The historical source manifest supplies provenance without bundling the source snapshots.
