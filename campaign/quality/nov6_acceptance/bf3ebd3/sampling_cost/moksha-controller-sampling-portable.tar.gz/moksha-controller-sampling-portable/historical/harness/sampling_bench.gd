extends SceneTree
# External measurement-only harness. Production sources are unmodified archives.
var host: Node
var label := ""
var run_id := ""
var results: Array[Dictionary] = []
var checks: Array[Dictionary] = []
var failed := false
var sink := 0

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--label="): label = arg.trim_prefix("--label=")
		if arg.begins_with("--run="): run_id = arg.trim_prefix("--run=")
	run.call_deferred()

func frames(n: int) -> void:
	for i in n: await process_frame

func freeze(node: Node) -> void:
	node.set_process(false)
	node.set_physics_process(false)
	for child in node.get_children(): freeze(child)

func pad_held(down: bool) -> void:
	var axis := InputEventJoypadMotion.new()
	axis.device = 0
	axis.axis = JOY_AXIS_LEFT_X
	axis.axis_value = 0.625 if down else 0.0
	Input.parse_input_event(axis)
	var button := InputEventJoypadButton.new()
	button.device = 0
	button.button_index = JOY_BUTTON_LEFT_SHOULDER
	button.pressed = down
	Input.parse_input_event(button)
	Input.flush_buffered_events()

func metrics() -> Dictionary:
	return {"objects": int(Performance.get_monitor(Performance.OBJECT_COUNT)), "resources": int(Performance.get_monitor(Performance.OBJECT_RESOURCE_COUNT)), "nodes": int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)), "orphans": int(Performance.get_monitor(Performance.OBJECT_ORPHAN_NODE_COUNT)), "static_bytes": OS.get_static_memory_usage()}

func ensure(ok: bool, name: String) -> void:
	checks.append({"ok": ok, "name": name})
	if not ok: failed = true

func exercise(method: String, iterations: int) -> int:
	var sum := 0
	if method == "raw":
		for i in iterations:
			var value: Dictionary = host._raw_campaign_input()
			sum += value.size()
	else:
		for i in iterations:
			var value: Dictionary = host._hud_snapshot()
			sum += value.size()
	return sum

func run() -> void:
	preload("res://combat_pc/player.gd").ensure_default_inputs()
	for scenario in ["neutral", "held_device0", "blocked_device0", "initial_held_device0", "explicit_override"]:
		pad_held(false)
		await frames(2)
		if scenario == "initial_held_device0":
			pad_held(true)
			await frames(2)
		host = load("res://campaign/campaign.tscn").instantiate()
		host.save_enabled = false
		root.add_child(host)
		host.start_new(true)
		freeze(host)
		host.input_override = null
		# Keep real room/goals/player/HUD and exact functions, but stop unrelated
		# physics/render process work so each batch sees the same starting state.
		await frames(3)
		if scenario in ["held_device0", "blocked_device0"]:
			pad_held(true)
			await frames(2)
		if scenario == "blocked_device0": host._capture_input_boundary()
		if scenario == "explicit_override":
			host.input_override = {"left": 0.0, "right": 0.5, "up": 0.0, "down": 0.0, "jump": false, "roll": false, "attack": false, "shield": true}
		var before_raw: Dictionary = host._raw_campaign_input()
		var before_hud: Dictionary = host._hud_snapshot()
		ensure(host.state == "playing", scenario + " is playing")
		ensure(is_equal_approx(float(before_raw.right), 0.0 if scenario == "neutral" else 0.5), scenario + " right strength")
		ensure(bool(before_raw.shield) == (scenario != "neutral"), scenario + " shield strength")
		ensure(not host._input_tick_active, scenario + " exercises raw-device path outside tick override")
		if scenario == "blocked_device0": ensure(str(before_hud.guidance).contains("release"), scenario + " HUD release guidance")
		var aliases := -1
		if label == "candidate":
			aliases = host._controller_bindings._aliases.size()
			ensure(aliases == 8, scenario + " eight native aliases")
		sink += exercise("raw", 1000)
		sink += exercise("hud", 300)
		var records: Array[Dictionary] = []
		var stable_before := metrics()
		for batch in 4:
			for method in (["raw", "hud"] if batch % 2 == 0 else ["hud", "raw"]):
				var iterations := 4000 if method == "raw" else 1000
				var before := metrics()
				var started := Time.get_ticks_usec()
				sink += exercise(method, iterations)
				var elapsed := Time.get_ticks_usec() - started
				var after := metrics()
				records.append({"batch": batch, "method": method, "iterations": iterations, "elapsed_usec": elapsed, "usec_per_call": float(elapsed) / iterations, "before": before, "after": after})
		var stable_after := metrics()
		ensure(before_raw == host._raw_campaign_input(), scenario + " unchanged raw snapshot after calls")
		ensure(before_hud == host._hud_snapshot(), scenario + " unchanged HUD snapshot after calls")
		results.append({"scenario": scenario, "aliases": aliases, "raw_snapshot": before_raw, "hud_guidance": before_hud.guidance, "hud_key_count": before_hud.size(), "stable_before": stable_before, "stable_after": stable_after, "measurements": records})
		pad_held(false)
		host.free()
		await frames(2)
	print("SAMPLING_BENCH_RESULT " + JSON.stringify({"label": label, "run": run_id, "engine": Engine.get_version_info(), "connected_joypads": Input.get_connected_joypads(), "passed": not failed, "checks": checks, "results": results, "sink": sink}))
	quit(1 if failed else 0)
