#!/usr/bin/env python3
import os,sys,pathlib,subprocess,json,time,datetime,platform,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]

def capture(label,run):
 env=dict(os.environ);home=ROOT/'homes'/run
 for key,sub in [('HOME','home'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data')]:
  path=home/sub;path.mkdir(parents=True,exist_ok=True);env[key]=str(path)
 cmd=['nice','-n','10','godot','--headless','--audio-driver','Dummy','--path',str(ROOT/label),'--script',str(ROOT/'harness/sampling_bench.gd'),'--',f'--label={label}',f'--run={run}']
 record={'command':cmd,'utc_start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load_before':os.getloadavg()}
 start=time.perf_counter()
 with (ROOT/'raw'/f'{run}.log').open('w') as out:
  process=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=50)
 record.update(exit_code=process.returncode,wall_seconds=time.perf_counter()-start,load_after=os.getloadavg(),utc_end=datetime.datetime.now(datetime.timezone.utc).isoformat())
 text=(ROOT/'raw'/f'{run}.log').read_text(); lines=[x.removeprefix('SAMPLING_BENCH_RESULT ') for x in text.splitlines() if x.startswith('SAMPLING_BENCH_RESULT ')]
 record['diagnostic_lines']=[x for x in text.splitlines() if 'ERROR' in x or 'WARNING' in x]
 if lines:record['result']=json.loads(lines[-1])
 (ROOT/'raw'/f'{run}.json').write_text(json.dumps(record,indent=2)+'\n')
 print(run,'rc',process.returncode,'wall',round(record['wall_seconds'],2),'diagnostics',len(record['diagnostic_lines']),flush=True)
 if process.returncode or not lines or record['diagnostic_lines'] or not record['result']['passed']:
  print(text[:5000],flush=True);raise SystemExit(1)

if __name__=='__main__':
 if len(sys.argv)>1:
  capture(sys.argv[1],f'pilot-{sys.argv[1]}')
 else:
  for pair in range(6):
   order=['baseline','candidate'] if pair%2==0 else ['candidate','baseline']
   for label in order:
    capture(label,f'pair{pair+1}-{label}')
    time.sleep(.5)
