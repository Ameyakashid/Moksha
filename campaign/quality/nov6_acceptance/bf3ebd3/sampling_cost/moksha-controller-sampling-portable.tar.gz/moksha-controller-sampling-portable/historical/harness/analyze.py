import pathlib,json,statistics,hashlib,collections,datetime
R=pathlib.Path(__file__).resolve().parents[1]
all_runs=[json.loads(p.read_text()) for p in sorted((R/'raw').glob('pair*-*.json'))]
assert len(all_runs)==12, len(all_runs)
assert all(r['exit_code']==0 and r['result']['passed'] and not r['diagnostic_lines'] for r in all_runs)
by={r['result']['run']:r for r in all_runs}
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':{'baseline':'b2e7f352b96b11e9a5137145416ddeaf4a974e27','candidate':'bf3ebd382eb9485eeaffcdff9fe9bfcfda8d3ad5'},'pairs':6,'measured_batches_per_label_per_path':24,'rows':[],'load_1m_min':min(r['load_before'][0] for r in all_runs),'load_1m_max':max(r['load_after'][0] for r in all_runs),'total_wall_seconds':sum(r['wall_seconds'] for r in all_runs),'assertions':sum(len(r['result']['checks']) for r in all_runs),'checks_passed':True,'cross_version_matches':[]}

def quantile(vals,q):
 vals=sorted(vals);p=(len(vals)-1)*q;lo=int(p);f=p-lo
 return vals[lo] if lo==len(vals)-1 else vals[lo]*(1-f)+vals[lo+1]*f

def stats(vals):
 return {'n':len(vals),'median':statistics.median(vals),'min':min(vals),'max':max(vals),'p10':quantile(vals,.1),'p90':quantile(vals,.9),'mean':statistics.mean(vals),'stdev':statistics.stdev(vals) if len(vals)>1 else 0}
scenarios=[s['scenario'] for s in all_runs[0]['result']['results']]
for case in scenarios:
 for pair in range(1,7):
  b=next(x for x in by[f'pair{pair}-baseline']['result']['results'] if x['scenario']==case)
  c=next(x for x in by[f'pair{pair}-candidate']['result']['results'] if x['scenario']==case)
  matched={k:b[k]==c[k] for k in ['raw_snapshot','hud_guidance','hud_key_count']}
  assert all(matched.values()), (case,pair,matched)
  summary['cross_version_matches'].append({'scenario':case,'pair':pair,**matched})
 for method in ['raw','hud']:
  row={'scenario':case,'path':method}
  perrun={}
  for label in ['baseline','candidate']:
   values=[];medians=[];object_deltas=[];resource_deltas=[];native_deltas=[]
   for pair in range(1,7):
    r=by[f'pair{pair}-{label}'];x=next(x for x in r['result']['results'] if x['scenario']==case)
    ms=[m for m in x['measurements'] if m['method']==method]
    vv=[m['usec_per_call'] for m in ms];values+=vv;medians.append(statistics.median(vv))
    object_deltas += [m['after']['objects']-m['before']['objects'] for m in ms]
    resource_deltas += [m['after']['resources']-m['before']['resources'] for m in ms]
    native_deltas += [m['after']['static_bytes']-m['before']['static_bytes'] for m in ms]
   row[label+'_batch_usec']=stats(values);row[label+'_process_median_usec']=stats(medians)
   row[label+'_object_deltas']=sorted(set(object_deltas));row[label+'_resource_deltas']=sorted(set(resource_deltas));row[label+'_native_metric_deltas_bytes']=sorted(set(native_deltas));perrun[label]=medians
  row['paired_delta_usec']=stats([c-b for b,c in zip(perrun['baseline'],perrun['candidate'])])
  row['candidate_over_baseline_median_ratio']=row['candidate_batch_usec']['median']/row['baseline_batch_usec']['median']
  summary['rows'].append(row)
retention=[]
for p in sorted((R/'raw').glob('retention*-*.json')):
 run=json.loads(p.read_text());assert run['exit_code']==0 and run['result']['passed'] and not run['diagnostic_lines']
 for case in run['result']['results']:
  x=case['measurements'][0];samples=x['memory_samples']
  retention.append({'run':run['result']['run'],'scenario':case['scenario'],**x,'net_native_memory_delta_bytes':samples[-1]-samples[0],'checkpoint_range_bytes':max(samples)-min(samples)})
summary['retention']=retention
manifest=json.loads((R/'source_manifest.json').read_text())
summary['source_file_changes']={k:[p for p,h in v['files'].items() if hashlib.sha256((R/k/p).read_bytes()).hexdigest()!=h] for k,v in manifest.items()}
(R/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for r in summary['rows']:
 print(r['scenario'],r['path'],'baseline',round(r['baseline_batch_usec']['median'],3),'candidate',round(r['candidate_batch_usec']['median'],3),'delta',round(r['paired_delta_usec']['median'],3),'paired_delta_range',round(r['paired_delta_usec']['min'],3),round(r['paired_delta_usec']['max'],3))
print('objects/resources deltas',set(tuple(x['candidate_object_deltas']) for x in summary['rows']),set(tuple(x['candidate_resource_deltas']) for x in summary['rows']))
print('retention',len(retention),'delta native',sorted(set(x['net_native_memory_delta_bytes'] for x in retention)))
print('load',summary['load_1m_min'],summary['load_1m_max'],'checks',summary['assertions'],'wall',summary['total_wall_seconds'])
