# Independent controller acceptance: frozen v5

Final: 9,226 passing positive assertions (4,582 composition/actor/lifecycle plus 31 cache/resource checks at each of 60 and 120 matching fixed/physics rates). Two separate frozen re-entry controls match expected outcomes: v2 correct strength 0 / exit 0; v4 stale strength 1 / exit 1. No unexpected final engine diagnostics or archived source/fixture drift. Full commands, engine identity, hashes, reports and raw diagnostics are under final/.

Base commit: b2e7f352b96b11e9a5137145416ddeaf4a974e27. Accepted runtime overlays and exact hashes appear in final/source_manifest.json and final/summary.json; the three captured files are under accepted_runtime/. Gamepad navigation is byte-identical to b2; only campaign.gd and controller_bindings.gd differ. Original actor, demo, audio and physics sources are not changed.

The same main fixture on v4 has 37 failures per rate. These failures cover four corrected classes: approximate ownership comparisons, stale held state after alias recreation, pre-mounted held-input leakage, and an off-tree focus/disconnect callback. See prior/v4_same_fixture/. Earlier v2 receipts retain the edited-alias erase-by-value collision and new helper orphan. v4 fixed both orphan lifetimes and the binding collision. No failed historical run has been relabeled as acceptance.

Observer-only pilot corrections: the early v2 namespace check compared a stored float32 deadzone with a decimal literal; the corrected check captures and compares the engine-stored value. The early cache fixture called a non-static method without an instance and failed to parse; its exact script and diagnostic remain under prior/v5_initial/evidence/cache_pilot_*. Those are test authoring errors, not runtime findings. Historical initial stress receipts may have fewer assertions as coverage was added. Every JSON receipt includes its exact fixture SHA, and the matching historical fixture source is retained where applicable.

The prior detached-disconnect log intentionally includes the real b2/v4 null-tree errors. The final accepted run includes no such errors. Baseline b2 orphan Nodes are explicitly cleaned up inside the ownership comparison; acceptance requires zero candidate orphans relative to pre-pass9e, not parity with b2's defect.

This is synthetic native-event and explicit API lifecycle evidence, not physical-controller, rendered or full-campaign traversal testing. Read reusable_source/README.md for setup and limits.
