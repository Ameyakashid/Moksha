#!/usr/bin/env python3
"""Hash-bound independent controller lifecycle/keyboard reference review.
The supplied repository and candidate are read only. All Godot runs use a new
archive-based snapshot and fresh XDG paths beneath --output.
"""
from __future__ import annotations
import argparse, hashlib, io, json, os, pathlib, re, shutil, subprocess, tarfile

BASE = 'b2e7f352b96b11e9a5137145416ddeaf4a974e27'
OVERLAYS = ('campaign/logic/campaign.gd', 'campaign/input/controller_bindings.gd', 'campaign/input/gamepad_navigation.gd')
HERE = pathlib.Path(__file__).resolve().parent
DIAGNOSTICS = re.compile(r'(?m)^(?:SCRIPT ERROR:|ERROR:|WARNING:.*(?:leaked|orphan))')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest(root):
    return {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*'))
            if p.is_file() and '.godot' not in p.parts}

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def invoke(command, env, logfile):
    with logfile.open('w') as handle:
        done = subprocess.run(command, env=env, stdout=handle, stderr=subprocess.STDOUT,
                              timeout=240, check=False)
    log = logfile.read_text()
    return {'command': command, 'exit_code': done.returncode,
            'diagnostics': DIAGNOSTICS.findall(log), 'log_sha256': sha(logfile)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', type=pathlib.Path, required=True)
    parser.add_argument('--candidate', type=pathlib.Path, required=True)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    parser.add_argument('--godot', default='godot')
    parser.add_argument('--rates', type=int, nargs='+', default=[60, 120])
    parser.add_argument('--expect-candidate', type=pathlib.Path,
                        help='Optional JSON dictionary of exact overlay path -> SHA256')
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        parser.error('--output must not exist; prior evidence is never overwritten')
    output.mkdir(parents=True)
    evidence = output / 'evidence'; evidence.mkdir()
    project = output / 'project'; project.mkdir()
    observed = {rel: sha(args.candidate / rel) for rel in OVERLAYS}
    if args.expect_candidate:
        expected = json.loads(args.expect_candidate.read_text())
        if any(observed.get(rel) != value for rel, value in expected.items()):
            raise RuntimeError('Candidate does not match the supplied expected hashes')
    archive = subprocess.check_output(['git', '-C', str(args.repository), 'archive', BASE])
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        tar.extractall(project, filter='data')
    for rel in OVERLAYS:
        target = project / rel; target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(args.candidate / rel, target)
    if observed != {rel: sha(args.candidate / rel) for rel in OVERLAYS}:
        raise RuntimeError('Candidate changed while snapshotting; no tests were run')
    if observed != {rel: sha(project / rel) for rel in OVERLAYS}:
        raise RuntimeError('Copied candidate hashes do not match')
    source = manifest(project)
    write(evidence / 'source_manifest.json', {'base_commit': BASE, 'overlays': observed,
                                             'archive_sha256': hashlib.sha256(archive).hexdigest(),
                                             'files': source})
    stage = project / 'campaign/quality/independent_multipad'; stage.mkdir(exist_ok=True)
    staged = {'review.gd': HERE/'review.gd',
              'baseline_campaign.gd': HERE/'baselines/b2_campaign.gd',
              'prepass_campaign.gd': HERE/'baselines/prepass_9e_campaign.gd'}
    for name, src in staged.items(): shutil.copy2(src, stage/name)
    fixture_hashes = {name: sha(stage/name) for name in staged}
    write(evidence/'fixture_manifest.json', fixture_hashes)
    initial = manifest(project)
    env = dict(os.environ)
    for variable, folder in [('XDG_DATA_HOME','data'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache')]:
        path = output/'runtime'/folder; path.mkdir(parents=True); env[variable] = str(path)
    engine = subprocess.check_output([args.godot, '--version'], env=env, text=True).strip()
    (evidence/'engine.txt').write_text(engine+'\n')
    imported = invoke([args.godot,'--headless','--editor','--path',str(project),'--import'], env, evidence/'import.log')
    runs=[]
    if imported['exit_code'] != 0 or imported['diagnostics']:
        raise RuntimeError('Snapshot import failed; see evidence/import.log')
    for rate in args.rates:
        report=evidence/f'review_{rate}.json'
        record=invoke([args.godot,'--headless','--path',str(project),'--fixed-fps',str(rate),
                       '--script','res://campaign/quality/independent_multipad/review.gd','--',
                       f'--hz={rate}',f'--out={report}'],env,evidence/f'review_{rate}.log')
        result=json.loads(report.read_text()) if report.exists() else {}
        record.update({'hz':rate,'checks':result.get('checks',0),'failures':result.get('failures',[]),
                       'report_sha256':sha(report) if report.exists() else None,
                       'passed':record['exit_code']==0 and not record['diagnostics'] and result.get('passed') is True
                                and result.get('harness_sha256')==fixture_hashes['review.gd']})
        runs.append(record)
    after=manifest(project)
    # Godot may add resource UID sidecars during import. Those new files are
    # recorded, but existing archived sources and staged fixtures must not change.
    drift=[rel for rel,digest in initial.items() if after.get(rel)!=digest]
    summary={'passed':all(r['passed'] for r in runs) and not drift,'engine':engine,
             'base_commit':BASE,'candidate':observed,'fixture_hashes':fixture_hashes,
             'import':imported,'runs':runs,'source_drift':drift,
             'generated_files':sorted(set(after)-set(initial))}
    write(evidence/'summary.json',summary)
    print(json.dumps({'passed':summary['passed'],'checks':sum(r['checks'] for r in runs),
                      'source_drift':drift,'summary':str(evidence/'summary.json')}))
    return 0 if summary['passed'] else 1

if __name__=='__main__': raise SystemExit(main())
