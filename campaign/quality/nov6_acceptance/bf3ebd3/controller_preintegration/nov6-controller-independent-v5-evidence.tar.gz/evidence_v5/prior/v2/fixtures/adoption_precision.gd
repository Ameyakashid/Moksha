extends SceneTree
var rows:Array=[]
func _initialize()->void:run.call_deferred()
func run()->void:
	preload("res://combat_pc/player.gd").ensure_default_inputs()
	for kind in ["deadzone_large","deadzone_small","axis_small"]:
		var adapter:Node=load("res://campaign/quality/independent_multipad/v3_bindings.gd").new();root.add_child(adapter)
		var alias:String=adapter._aliases.cp_right.name
		var original:float=InputMap.action_get_deadzone(alias)
		var changed:float
		if kind.begins_with("deadzone"):
			InputMap.action_set_deadzone(alias,0.6 if kind=="deadzone_large" else original+0.000001)
			changed=InputMap.action_get_deadzone(alias)
		else:
			var event:InputEventJoypadMotion=InputMap.action_get_events(alias)[-1]
			original=event.axis_value;event.axis_value=original+0.000001;changed=event.axis_value
		var guard:bool=adapter._alias_unchanged(adapter._aliases.cp_right)
		adapter.free()
		rows.append({"kind":kind,"original":original,"changed":changed,"actual_change":changed!=original,"guard_says_unchanged":guard,"alias_preserved":InputMap.has_action(alias)})
		if InputMap.has_action(alias):InputMap.erase_action(alias)
	print("ADOPTION_PRECISION "+JSON.stringify(rows))
	quit()
